const api = globalThis.browser ?? globalThis.chrome;
const DEFAULTS = { tabAudio: true, mic: false, fps: 30, countdown: true, imageFormat: 'png', copyShots: true, saveAs: false };
let S = { ...DEFAULTS };

setHTML(document.getElementById('logo'), LENS_LOGO);
document.getElementById('ver').textContent = 'Version ' + api.runtime.getManifest().version;

function render() {
  document.querySelectorAll('.switch[data-k]').forEach(b => b.classList.toggle('on', !!S[b.dataset.k]));
  document.querySelectorAll('.pills[data-k]').forEach(g => g.querySelectorAll('.pillbtn').forEach(b => b.classList.toggle('on', String(S[g.dataset.k]) === b.dataset.v)));
}

async function load() {
  S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  render();
}

document.querySelectorAll('.switch[data-k]').forEach(b => b.onclick = async () => {
  const k = b.dataset.k;
  S[k] = !S[k];
  await api.storage.local.set({ [k]: S[k] });
  render();
  if (k === 'mic' && S.mic) checkMic(true);
});
document.querySelectorAll('.pills[data-k]').forEach(g => g.querySelectorAll('.pillbtn').forEach(b => b.onclick = async () => {
  const k = g.dataset.k;
  S[k] = typeof DEFAULTS[k] === 'number' ? Number(b.dataset.v) : b.dataset.v;
  await api.storage.local.set({ [k]: S[k] });
  render();
}));

async function checkMic(ask) {
  try {
    const p = await navigator.permissions.query({ name: 'microphone' });
    if (p.state === 'granted') { setHTML(document.getElementById('micSub'), '<span class="ok">Microphone allowed</span>'); return; }
  } catch {}
  if (ask) {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach(t => t.stop());
      setHTML(document.getElementById('micSub'), '<span class="ok">Microphone allowed</span>');
    } catch {
      document.getElementById('micSub').textContent = 'Microphone is blocked in your browser settings';
    }
  }
}

async function showKey() {
  try {
    const cmds = await api.commands.getAll();
    const c = cmds.find(x => x.name === '_execute_action');
    document.getElementById('key').textContent = (c && c.shortcut) || 'Not set';
  } catch {}
}
document.getElementById('changeKey').onclick = () => {
  const firefox = typeof browser !== 'undefined' && navigator.userAgent.includes('Firefox');
  if (firefox) { alert('In Firefox: open about:addons, click the gear icon, then "Manage Extension Shortcuts".'); return; }
  const edge = navigator.userAgent.includes('Edg/');
  api.tabs.create({ url: edge ? 'edge://extensions/shortcuts' : 'chrome://extensions/shortcuts' });
};

api.storage.onChanged.addListener(load);
load();
showKey();
if (S.mic) checkMic(false);
