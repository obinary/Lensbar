const api = globalThis.browser ?? globalThis.chrome;
const DEFAULTS = { tabAudio: true, mic: false, fps: 30, countdown: true, imageFormat: 'png', copyShots: true, saveAs: false, shotFolder: 'Lensbar', recFolder: 'Lensbar' };
/** A folder inside Downloads, made safe for the downloads API ("Work/Shots" is fine; "..", "C:" and odd characters are not). */
function cleanFolder(f) {
  const parts = String(f || '').replace(/\\/g, '/').split('/')
    .map(p => p.replace(/[<>:"|?*\u0000-\u001f]/g, '').replace(/^[. ]+|[. ]+$/g, '').trim())
    .filter(p => p && p !== '..' && p !== '.');
  return parts.join('/').slice(0, 120);
}

let S = { ...DEFAULTS };

setHTML(document.getElementById('logo'), LENS_LOGO);
document.getElementById('ver').textContent = 'Version ' + api.runtime.getManifest().version;

function render() {
  document.querySelectorAll('input[data-f]').forEach(i => { if (document.activeElement !== i) i.value = S[i.dataset.f] || ''; });
  const sf = cleanFolder(S.shotFolder), rf = cleanFolder(S.recFolder);
  document.getElementById('savePath').textContent = S.saveAs ? 'You\'ll choose the place for every file.'
    : `Screenshots: Downloads${sf ? '/' + sf : ''}  ·  Recordings: Downloads${rf ? '/' + rf : ''}`;
  document.querySelectorAll('.switch[data-k]').forEach(b => b.classList.toggle('on', !!S[b.dataset.k]));
  document.querySelectorAll('.pills[data-k]').forEach(g => g.querySelectorAll('.pillbtn').forEach(b => b.classList.toggle('on', String(S[g.dataset.k]) === b.dataset.v)));
}

async function load() {
  S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  render();
}

document.querySelectorAll('.switch[data-k]').forEach(b => b.onclick = async () => {
  const k = b.dataset.k;
  S[k] = !S[k];
  await api.storage.local.set({ [k]: S[k] });
  render();
  if (k === 'mic' && S.mic) checkMic(true);
});
document.querySelectorAll('.pills[data-k]').forEach(g => g.querySelectorAll('.pillbtn').forEach(b => b.onclick = async () => {
  const k = g.dataset.k;
  S[k] = typeof DEFAULTS[k] === 'number' ? Number(b.dataset.v) : b.dataset.v;
  await api.storage.local.set({ [k]: S[k] });
  render();
}));

async function checkMic(ask) {
  try {
    const p = await navigator.permissions.query({ name: 'microphone' });
    if (p.state === 'granted') { setHTML(document.getElementById('micSub'), '<span class="ok">Microphone allowed</span>'); return; }
  } catch {}
  if (ask) {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach(t => t.stop());
      setHTML(document.getElementById('micSub'), '<span class="ok">Microphone allowed</span>');
    } catch {
      document.getElementById('micSub').textContent = 'Microphone is blocked in your browser settings';
    }
  }
}

document.querySelectorAll('input[data-f]').forEach(i => {
  const commit = async () => {
    const v = cleanFolder(i.value);
    i.value = v;
    S[i.dataset.f] = v;
    await api.storage.local.set({ [i.dataset.f]: v });
    render();
  };
  i.addEventListener('change', commit);
  i.addEventListener('keydown', e => { if (e.key === 'Enter') i.blur(); });
});
document.getElementById('openDl').onclick = () => { try { api.downloads.showDefaultFolder(); } catch {} };

api.storage.onChanged.addListener(load);
load();
if (S.mic) checkMic(false);
