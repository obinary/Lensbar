const api = globalThis.browser ?? globalThis.chrome;
const DEFAULTS = { tabAudio: true, mic: false, fps: 30, quality: 'high', soundQuality: 'high', countdown: true, imageFormat: 'png', copyShots: true, saveAs: false, shotFolder: 'Lensbar', recFolder: 'Lensbar' };
/** A folder inside Downloads, made safe for the downloads API ("Work/Shots" is fine; "..", "C:" and odd characters are not). */
function cleanFolder(f) {
  const parts = String(f || '').replace(/\\/g, '/').split('/')
    .map(p => p.replace(/[<>:"|?*\u0000-\u001f]/g, '').replace(/^[. ]+|[. ]+$/g, '').trim())
    .filter(p => p && p !== '..' && p !== '.');
  return parts.join('/').slice(0, 120);
}

let S = { ...DEFAULTS };

setHTML(document.getElementById('logo'), LENS_LOGO);
document.getElementById('ver').textContent = 'Version ' + api.runtime.getManifest().version;

const WIN = /win/i.test(navigator.platform || navigator.userAgent);
let dlRoot = '';   // the real Downloads folder, learned after the first save (see background.js)

/** "C:\Users\you\Downloads\Lensbar" (or "Downloads\Lensbar" until the real path is known) */
function fullPath(folder) {
  const sep = dlRoot ? (dlRoot.includes('\\') ? '\\' : '/') : (WIN ? '\\' : '/');
  const root = dlRoot || 'Downloads';
  const f = cleanFolder(folder);
  return f ? root.replace(/[\\/]$/, '') + sep + f.split('/').join(sep) : root;
}

function render() {
  // the size of a typical 1080p recording at the chosen quality and frame rate
  const per = { standard: 0.08, high: 0.16, best: 0.3 }[S.quality] || 0.16;
  const mbps = Math.max(2.5, Math.round(1920 * 1080 * S.fps * per / 1e5) / 10);
  document.getElementById('qSub').textContent = `About ${mbps} Mbps at 1080p`;
  document.getElementById('sqSub').textContent = S.soundQuality === 'standard' ? '128 kbps, smaller files' : '192 kbps, clearer sound';
  document.querySelectorAll('.frow').forEach(r => {
    const k = r.dataset.f;
    r.classList.toggle('off', !!S.saveAs);
    if (r.classList.contains('editing')) return;
    setPathText(r.querySelector('.path'), S.saveAs ? 'Asks every time' : fullPath(S[k]));
  });
  document.querySelectorAll('.switch[data-k]').forEach(b => b.classList.toggle('on', !!S[b.dataset.k]));
  document.querySelectorAll('.pills[data-k]').forEach(g => g.querySelectorAll('.pillbtn').forEach(b => b.classList.toggle('on', String(S[g.dataset.k]) === b.dataset.v)));
}

function setPathText(el, text) {
  // shown right-aligned-overflow so a long path keeps its end ("…\Downloads\Lensbar") visible
  el.textContent = '';
  const b = document.createElement('bdi'); b.textContent = text; el.appendChild(b);
  el.title = text;
}

async function load() {
  S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  dlRoot = (await api.storage.local.get({ dlRoot: '' })).dlRoot || '';
  render();
}

document.querySelectorAll('.switch[data-k]').forEach(b => b.onclick = async () => {
  const k = b.dataset.k;
  S[k] = !S[k];
  await api.storage.local.set({ [k]: S[k] });
  render();
  if (k === 'mic' && S.mic) checkMic(true);
});
document.querySelectorAll('.pills[data-k]').forEach(g => g.querySelectorAll('.pillbtn').forEach(b => b.onclick = async () => {
  const k = g.dataset.k;
  S[k] = typeof DEFAULTS[k] === 'number' ? Number(b.dataset.v) : b.dataset.v;
  await api.storage.local.set({ [k]: S[k] });
  render();
}));

async function checkMic(ask) {
  try {
    const p = await navigator.permissions.query({ name: 'microphone' });
    if (p.state === 'granted') { setHTML(document.getElementById('micSub'), '<span class="ok">Microphone allowed</span>'); return; }
  } catch {}
  if (ask) {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach(t => t.stop());
      setHTML(document.getElementById('micSub'), '<span class="ok">Microphone allowed</span>');
    } catch {
      document.getElementById('micSub').textContent = 'Microphone is blocked in your browser settings';
    }
  }
}

// Change -> the path turns into a field ("…\Downloads\ [Lensbar]") and the button into Save; Esc cancels.
document.querySelectorAll('.frow').forEach(r => {
  const k = r.dataset.f, input = r.querySelector('input'), btn = r.querySelector('.change');
  const close = () => { r.classList.remove('editing'); btn.textContent = 'Change'; btn.classList.remove('primary'); render(); };
  const save = async () => {
    const v = cleanFolder(input.value);
    S[k] = v;
    await api.storage.local.set({ [k]: v });
    close();
  };
  btn.onclick = () => {
    if (r.classList.contains('editing')) { save(); return; }
    document.querySelectorAll('.frow.editing').forEach(o => { o.classList.remove('editing'); const b = o.querySelector('.change'); b.textContent = 'Change'; b.classList.remove('primary'); });
    const sep = dlRoot ? (dlRoot.includes('\\') ? '\\' : '/') : (WIN ? '\\' : '/');
    setPathText(r.querySelector('.pre'), (dlRoot || 'Downloads').replace(/[\\/]$/, '') + sep);
    input.value = cleanFolder(S[k]).split('/').join(sep);
    r.classList.add('editing');
    btn.textContent = 'Save'; btn.classList.add('primary');
    input.focus(); input.select();
  };
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') save();
    if (e.key === 'Escape') { e.preventDefault(); close(); }
  });
});
document.getElementById('openDl').onclick = () => { try { api.downloads.showDefaultFolder(); } catch {} };

api.storage.onChanged.addListener(load);
load();
if (S.mic) checkMic(false);
