const api = globalThis.browser ?? globalThis.chrome;
const $ = id => document.getElementById(id);
const DEFAULTS = { tabAudio: true, mic: false, lastTab: 'shot' };
let S = { ...DEFAULTS };
let tab = null, pageOk = true, canTabCapture = true;

const MODES = {
  rec: [
    { id: 'tab', icon: 'tab', label: 'Record this tab (just the website)' },
    { id: 'area', icon: 'area', label: 'Record an area of the page' },
    { id: 'screen', icon: 'browser', label: 'Record the whole browser window' },
  ],
  shot: [
    { id: 'visible', icon: 'visible', label: 'Screenshot the visible part' },
    { id: 'area', icon: 'area', label: 'Screenshot an area' },
    { id: 'full', icon: 'fullpage', label: 'Full page, top to bottom' },
  ],
};

function show(view) { for (const v of document.querySelectorAll('.view')) v.classList.toggle('show', v.id === view); }

// ------------------------------------------------------------------ menu

function available(kind, id) {
  if (kind === 'rec' && id === 'screen') return true;
  if (!pageOk) return false;
  if (kind === 'rec' && !canTabCapture) return false;
  return true;
}

function renderMenu() {
  const shot = S.lastTab !== 'rec';
  $('seg').classList.toggle('shot', shot);
  $('modes-rec').classList.toggle('gone', shot);
  $('modes-shot').classList.toggle('gone', !shot);
  document.querySelector('.foot').classList.toggle('gone', shot);
  for (const kind of ['rec', 'shot']) {
    for (const b of $('modes-' + kind).children) b.classList.toggle('na', !available(kind, b.dataset.id));
  }
  setHTML($('tabAudio'), lensIcon(S.tabAudio ? 'speaker' : 'speakerOff', 15) + '<span>Tab sound</span>');
  $('tabAudio').classList.toggle('off', !S.tabAudio);
  setHTML($('mic'), lensIcon(S.mic ? 'mic' : 'micOff', 15) + '<span>Mic</span>');
  $('mic').classList.toggle('off', !S.mic);
  const note = $('note');
  if (!pageOk) {
    note.textContent = 'This is a browser page, which doesn\'t allow extensions. Open any website to take screenshots or record it. Recording the whole browser window works everywhere.';
  } else if (!canTabCapture && !shot) {
    note.textContent = 'This browser can\'t record a single tab. Use "Record the whole browser window".';
  } else note.textContent = '';
  note.classList.toggle('show', !!note.textContent);
}

function buildModes() {
  for (const kind of ['rec', 'shot']) {
    const box = $('modes-' + kind);
    for (const m of MODES[kind]) {
      const b = document.createElement('button');
      b.className = 'mode';
      b.dataset.id = m.id;
      setHTML(b, lensIcon(m.icon, 23) + (kind === 'rec' ? '<span class="dot"></span>' : ''));
      b.onmouseenter = () => { $('label').textContent = available(kind, m.id) ? m.label : m.label + ' (not here)'; };
      b.onmouseleave = () => { $('label').textContent = ''; };
      b.onclick = () => choose(kind, m.id);
      box.appendChild(b);
    }
  }
}

async function choose(kind, id) {
  if (!available(kind, id)) return;
  const r = await api.runtime.sendMessage({ type: 'run', kind, mode: id, tabId: tab && tab.id });
  if (r && r.ok === false && r.error === 'blocked') { pageOk = false; renderMenu(); return; }
  window.close();
}

async function save(patch) {
  Object.assign(S, patch);
  await api.storage.local.set(patch);
  renderMenu();
}

async function openMenu() {
  S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  const forced = Number(new URLSearchParams(location.search).get('tab'));   // used by automated tests
  if (forced) tab = await api.tabs.get(forced);
  else [tab] = await api.tabs.query({ active: true, currentWindow: true });
  pageOk = true;   // assume yes; the probe below greys things out only if the page really refuses
  try { canTabCapture = (await api.runtime.sendMessage({ type: 'can-tab-capture' })).value !== false; } catch {}
  setHTML($('logo'), LENS_LOGO);
  setHTML($('gear'), lensIcon('gear', 16));
  setHTML($('tab-rec'), lensIcon('record', 14) + 'Record');
  setHTML($('tab-shot'), lensIcon('camera', 14) + 'Screenshot');
  buildModes();
  renderMenu();
  show('menu');
  if (tab && tab.id != null) {
    try {
      const r = await api.runtime.sendMessage({ type: 'probe', tabId: tab.id });
      if (r && r.allowed === false) { pageOk = false; renderMenu(); }
    } catch {}
  }
}

$('tab-rec').onclick = () => { if (S.lastTab !== 'rec') { flash(); save({ lastTab: 'rec' }); } };
$('tab-shot').onclick = () => { if (S.lastTab !== 'shot') { flash(); save({ lastTab: 'shot' }); } };
function flash() { $('pill').classList.add('moving'); setTimeout(() => $('pill').classList.remove('moving'), 220); }
$('tabAudio').onclick = () => save({ tabAudio: !S.tabAudio });
$('mic').onclick = async () => {
  await save({ mic: !S.mic });
  if (S.mic) {
    const r = await api.runtime.sendMessage({ type: 'mic-check' });
    if (r && r.granted === false) api.runtime.sendMessage({ type: 'ask-mic' });
  }
};
$('gear').onclick = () => { api.runtime.openOptionsPage(); window.close(); };

// ------------------------------------------------------------------ recording controls

let state = { elapsed: 0, paused: false, mic: false, tabAudio: true, mode: 'tab' };
let base = 0, baseAt = performance.now();

function renderRec() {
  const t = state.paused ? state.elapsed : base + (performance.now() - baseAt) / 1000;
  $('time').textContent = lensFmt(t);
  $('dot').classList.toggle('paused', !!state.paused);
  $('what').textContent = state.paused ? 'Paused' : ({ tab: 'Recording tab', area: 'Recording area', screen: 'Recording browser window' }[state.mode] || 'Recording');
  setHTML($('r-pause'), lensIcon(state.paused ? 'play' : 'pause'));
  $('r-pause').title = state.paused ? 'Resume' : 'Pause';
  setHTML($('r-mic'), lensIcon(state.mic ? 'mic' : 'micOff'));
  $('r-mic').classList.toggle('off', !state.mic);
  setHTML($('r-tabAudio'), lensIcon(state.tabAudio ? 'speaker' : 'speakerOff'));
  $('r-tabAudio').classList.toggle('off', !state.tabAudio);
  $('r-tabAudio').title = (state.mode === 'screen' ? 'Sound' : 'Tab sound') + (state.tabAudio ? ': on' : ': off');
  setHTML($('r-discard'), lensIcon('trash'));
  setHTML($('r-stop'), lensIcon('stop'));
}
function apply(s) {
  if (!s) return;
  state = { ...state, ...s };
  base = state.elapsed || 0;
  baseAt = performance.now();
  renderRec();
}
const cmd = c => api.runtime.sendMessage({ type: 'rec-command', cmd: c });
$('r-pause').onclick = () => { cmd('toggle-pause'); state.paused = !state.paused; renderRec(); };
$('r-mic').onclick = () => cmd('toggle-mic');
$('r-tabAudio').onclick = () => cmd('toggle-tabaudio');
$('r-stop').onclick = async () => { await cmd('stop'); setTimeout(() => window.close(), 150); };
$('r-discard').onclick = () => $('confirm').classList.add('show');
$('keep').onclick = () => $('confirm').classList.remove('show');
$('yes').onclick = async () => { await cmd('discard'); setTimeout(() => window.close(), 150); };

api.runtime.onMessage.addListener(msg => {
  if (msg && msg.type === 'rec-tick') apply(msg);
  if (msg && msg.type === 'rec-finished') window.close();
});

// ------------------------------------------------------------------ start

api.runtime.sendMessage({ type: 'rec-state' }).then(r => {
  if (r && r.rec) {
    apply(r.rec);
    show('rec');
    setInterval(renderRec, 250);
  } else {
    openMenu();
  }
});
