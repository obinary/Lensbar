const api = globalThis.browser ?? globalThis.chrome;
const $ = id => document.getElementById(id);

if (new URLSearchParams(location.search).has('blocked')) {
  document.body.classList.add('is-blocked');
  setHTML($('logo'), LENS_LOGO);
  api.action.setPopup({ popup: '' }).catch(() => {});
  $('screen').onclick = async () => { await api.runtime.sendMessage({ type: 'rec-screen' }); window.close(); };
} else {
  let state = { elapsed: 0, paused: false, mic: false, tabAudio: true, mode: 'tab' };
  let base = 0, baseAt = performance.now();

  function render() {
    const t = state.paused ? state.elapsed : base + (performance.now() - baseAt) / 1000;
    $('time').textContent = lensFmt(t);
    $('dot').classList.toggle('paused', !!state.paused);
    $('what').textContent = state.paused ? 'Paused' : ({ tab: 'Recording tab', area: 'Recording area', screen: 'Recording screen' }[state.mode] || 'Recording');
    setHTML($('pause'), lensIcon(state.paused ? 'play' : 'pause'));
    $('pause').title = state.paused ? 'Resume' : 'Pause';
    setHTML($('mic'), lensIcon(state.mic ? 'mic' : 'micOff'));
    $('mic').classList.toggle('off', !state.mic);
    $('mic').title = state.mic ? 'Microphone: on' : 'Microphone: off';
    setHTML($('tabAudio'), lensIcon(state.tabAudio ? 'speaker' : 'speakerOff'));
    $('tabAudio').classList.toggle('off', !state.tabAudio);
    $('tabAudio').title = (state.mode === 'screen' ? 'System sound' : 'Tab sound') + (state.tabAudio ? ': on' : ': off');
    setHTML($('discard'), lensIcon('trash'));
    setHTML($('stop'), lensIcon('stop'));
  }

  function apply(s) {
    if (!s) return;
    state = { ...state, ...s };
    base = state.elapsed || 0;
    baseAt = performance.now();
    render();
  }

  api.runtime.sendMessage({ type: 'rec-state' }).then(r => {
    if (!r || !r.rec) { window.close(); return; }
    apply(r.rec);
  });
  api.runtime.onMessage.addListener(msg => {
    if (msg && msg.type === 'rec-tick') apply(msg);
    if (msg && msg.type === 'rec-finished') window.close();
  });
  setInterval(render, 250);

  const cmd = c => api.runtime.sendMessage({ type: 'rec-command', cmd: c });
  $('pause').onclick = () => { cmd('toggle-pause'); state.paused = !state.paused; render(); };
  $('mic').onclick = () => { cmd('toggle-mic'); };
  $('tabAudio').onclick = () => { cmd('toggle-tabaudio'); };
  $('stop').onclick = async () => { await cmd('stop'); setTimeout(() => window.close(), 150); };
  $('discard').onclick = () => $('confirm').classList.add('show');
  $('keep').onclick = () => $('confirm').classList.remove('show');
  $('yes').onclick = async () => { await cmd('discard'); setTimeout(() => window.close(), 150); };
  render();
}
