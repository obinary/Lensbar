function setHTML(el, str) {
  // builds markup through DOMParser (no innerHTML), then moves the nodes in
  const doc = new DOMParser().parseFromString(`<body>${str}</body>`, 'text/html');
  el.replaceChildren(...Array.from(doc.body.childNodes).map(n => document.importNode(n, true)));
}
// Shared stroked icons for the extension pages (24×24).
const LENS_ICONS = {
  speaker: '<path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6"/><path d="M18 6.5a7.8 7.8 0 0 1 0 11"/>',
  speakerOff: '<path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4z"/><path d="M16 9.5l5 5"/><path d="M21 9.5l-5 5"/>',
  mic: '<rect x="9" y="3" width="6" height="11.5" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0"/><path d="M12 18v3"/>',
  micOff: '<rect x="9" y="3" width="6" height="11.5" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0"/><path d="M12 18v3"/><path d="M4 4l16 16"/>',
  pause: '<rect x="6.5" y="5" width="3.8" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.7" y="5" width="3.8" height="14" rx="1.2" fill="currentColor" stroke="none"/>',
  play: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor" stroke="none"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor" stroke="none"/>',
  trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.8h5V7"/><path d="M6.5 7l1 12.5h9l1-12.5"/><path d="M10.2 10.5v6"/><path d="M13.8 10.5v6"/>',
  screen: '<rect x="3" y="4.5" width="18" height="12" rx="2"/><path d="M9 20h6"/><path d="M12 16.5V20"/>',
  browser: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M3 8.8h18"/><path d="M6.2 6.65h.01"/><path d="M8.6 6.65h.01"/><path d="M10.2 12.2H7.6v2.6"/><path d="M13.8 16.6h2.6V14"/>',
  tab: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3 9.5h18"/><path d="M6.5 7.25h.01"/><path d="M9 7.25h.01"/>',
  area: '<path d="M4 8V6a2 2 0 0 1 2-2h2"/><path d="M16 4h2a2 2 0 0 1 2 2v2"/><path d="M20 16v2a2 2 0 0 1-2 2h-2"/><path d="M8 20H6a2 2 0 0 1-2-2v-2"/><path d="M11 4h2"/><path d="M11 20h2"/><path d="M4 11v2"/><path d="M20 11v2"/>',
  visible: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M8 9.5h8"/><path d="M8 12.5h8"/><path d="M8 15.5h5"/>',
  fullpage: '<rect x="6" y="2.5" width="12" height="19" rx="2"/><path d="M12 7v9"/><path d="M9 13l3 3 3-3"/>',
  record: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.4" fill="currentColor" stroke="none"/>',
  camera: '<path d="M4 8.5a2 2 0 0 1 2-2h2.2l1.5-2h4.6l1.5 2H18a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="12.6" r="3.3"/>',
};
(function () {
  // cog drawn from 8 rounded teeth
  const cx = 12, cy = 12, ro = 9.3, ri = 7.1, n = 8, step = Math.PI * 2 / n;
  let d = '';
  for (let i = 0; i < n; i++) {
    const a0 = i * step;
    for (const [a, r] of [[a0 - step * 0.18, ri], [a0 - step * 0.12, ro], [a0 + step * 0.12, ro], [a0 + step * 0.18, ri], [a0 + step * 0.5, ri]]) {
      d += (d ? 'L' : 'M') + (cx + r * Math.cos(a)).toFixed(2) + ' ' + (cy + r * Math.sin(a)).toFixed(2);
    }
  }
  LENS_ICONS.gear = `<path d="${d}Z"/><circle cx="12" cy="12" r="3"/>`;
})();
function lensIcon(name, size = 17) {
  return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${LENS_ICONS[name]}</svg>`;
}
const LENS_LOGO = `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round">
  <path d="M1.9 6.1V3.5Q1.9 1.9 3.5 1.9H6.1"/><path d="M9.9 1.9h2.6q1.6 0 1.6 1.6v2.6"/><path d="M14.1 9.9v2.6q0 1.6-1.6 1.6H9.9"/><path d="M6.1 14.1H3.5q-1.6 0-1.6-1.6V9.9"/>
  <circle cx="8" cy="8" r="2" fill="currentColor" stroke="none"/></svg>`;
function lensFmt(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec % 60, p = n => String(n).padStart(2, '0');
  return h ? `${h}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
}
