// Lensbar: turns a WebM recording (Firefox's only format) into an MP4 with Mediabunny, using the browser's own
// encoders. Shared by the recorder window and Firefox's background page. Keeps the WebM if that isn't possible.
// var (not const): this file can be loaded more than once into the same page.
var lensToMp4 = async function (blob, { fps = 30, quality = 'high', soundQuality = 'high', cropFor = null, onProgress = null } = {}) {
  if (!blob || !globalThis.VideoEncoder) return null;
  try {
    const MB = await import('./lib/mediabunny.min.mjs');
    const input = new MB.Input({ source: new MB.BlobSource(blob), formats: MB.ALL_FORMATS });
    const vt = await input.getPrimaryVideoTrack();
    if (!vt) return null;
    const W = await vt.getDisplayWidth(), H = await vt.getDisplayHeight();
    let crop = cropFor ? cropFor(W, H) : null;                  // part of the picture to keep, or null for all
    // a shared window is often an odd number of pixels wide or tall, which many H.264 encoders refuse: trim 1 px
    if (!crop && (W % 2 || H % 2)) crop = { left: 0, top: 0, width: W & ~1, height: H & ~1 };
    const hasAudio = (await input.getAudioTracks()).length > 0;
    const per = { standard: [0.08, 2.5e6, 12e6], high: [0.16, 5e6, 30e6], best: [0.3, 8e6, 60e6] }[quality] || [0.16, 5e6, 30e6];
    const outW = crop ? crop.width : W, outH = crop ? crop.height : H;
    const bitrate = Math.round(Math.max(per[1], Math.min(per[2], outW * outH * Math.max(24, fps) * per[0])));
    // H.264 plays everywhere; VP9 / AV1 in an MP4 are fallbacks. A browser may say it can make H.264 and then not
    // manage it at this picture size, so each choice is checked: picture AND sound must both make it into the MP4.
    const vcodecs = [];
    for (const c of ['avc', 'vp9', 'av1']) if (await MB.canEncodeVideo(c, { width: outW & ~1, height: outH & ~1, bitrate })) vcodecs.push(c);
    const abr = soundQuality === 'standard' ? 128000 : 192000;
    // AAC plays everywhere; where the browser can't make AAC, the recorded Opus sound goes into the MP4 as it is
    const audios = (await MB.canEncodeAudio('aac')) ? [{ codec: 'aac', bitrate: abr }, {}] : [{}];
    let conv = null, output = null;
    for (const vcodec of vcodecs) {
      const video = { codec: vcodec, bitrate };
      if (crop) video.crop = crop;
      for (const audio of audios) {
        output = new MB.Output({ format: new MB.Mp4OutputFormat({ fastStart: 'in-memory' }), target: new MB.BufferTarget() });
        const c = await MB.Conversion.init({ input, output, video, audio, showWarnings: false });
        const lost = c.discardedTracks.filter(d => d.track.type === 'video' || (hasAudio && d.track.type === 'audio'));
        if (c.isValid && !lost.length) { conv = c; break; }
        console.warn('Lensbar: MP4 with', vcodec, 'would drop', lost.map(d => d.track.type + ' (' + d.reason + ')').join(', '));
      }
      if (conv) break;
    }
    if (!conv) return null;                                     // keep the WebM rather than lose the sound
    if (onProgress) conv.onProgress = onProgress;
    await conv.execute();
    const mp4 = new Blob([output.target.buffer], { type: 'video/mp4' });
    // last check: the finished MP4 really has a picture (otherwise the original WebM is saved instead)
    const check = new MB.Input({ source: new MB.BlobSource(mp4), formats: MB.ALL_FORMATS });
    const cv = await check.getPrimaryVideoTrack();
    if (!cv || !(await cv.computeDuration().catch(() => 0))) { console.warn('Lensbar: MP4 came out without a picture, keeping WebM'); return null; }
    return mp4;
  } catch (e) {
    console.warn('Lensbar: MP4 conversion failed, keeping WebM', e);
    return null;
  }
};
