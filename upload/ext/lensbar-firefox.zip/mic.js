setHTML(document.getElementById('logo'), LENS_LOGO);
document.getElementById('allow').onclick = async () => {
  const msg = document.getElementById('msg');
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true });
    s.getTracks().forEach(t => t.stop());
    msg.textContent = 'Done. The microphone is ready.';
    setTimeout(() => window.close(), 900);
  } catch (e) {
    msg.textContent = 'The microphone is blocked. Allow it in your browser\'s site settings for Lensbar, then try again.';
  }
};
