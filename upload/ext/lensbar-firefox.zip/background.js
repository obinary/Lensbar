// Lensbar for browsers: background (service worker in Chrome/Edge/Opera/Brave, event page in Firefox).
const api = globalThis.browser ?? globalThis.chrome;
const CAN_TAB_CAPTURE = !!(api.offscreen && api.tabCapture);   // Chromium browsers
// Firefox records from the page itself (its "Allow … to see your screen?" box), so the page gets the recorder too
const PAGE_SCRIPTS = CAN_TAB_CAPTURE ? ['content.js'] : ['recorder-core.js', 'content.js'];

const DEFAULTS = {
  tabAudio: true, mic: false, fps: 30, countdown: true, quality: 'high', soundQuality: 'high',
  imageFormat: 'png', copyShots: true, saveAs: false, lastTab: 'shot', pinned: false,
  shotFolder: 'Lensbar', recFolder: 'Lensbar',
};

/** A folder inside Downloads, made safe for the downloads API ("Work/Shots" is fine; "..", "C:" and odd characters are not). */
function cleanFolder(f) {
  const parts = String(f || '').replace(/\\/g, '/').split('/')
    .map(p => p.replace(/[<>:"|?*\u0000-\u001f]/g, '').replace(/^[. ]+|[. ]+$/g, '').trim())
    .filter(p => p && p !== '..' && p !== '.');
  return parts.join('/').slice(0, 120);
}


async function getSettings() {
  const s = await api.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...s };
}

// ------------------------------------------------------------------ recording state

async function getRec() {
  const { rec } = await api.storage.session.get('rec');
  return rec || null;
}
async function setRec(rec) {
  if (rec) await api.storage.session.set({ rec });
  else await api.storage.session.remove('rec');
}

function fmt(sec) {
  sec = Math.max(0, Math.floor(sec));
  const m = Math.floor(sec / 60), s = sec % 60;
  return m >= 100 ? `${m}m` : `${m}:${String(s).padStart(2, '0')}`;
}

async function badge(text, color = '#E5484D') {
  try {
    await api.action.setBadgeBackgroundColor({ color });
    if (api.action.setBadgeTextColor) await api.action.setBadgeTextColor({ color: '#FFFFFF' });
    await api.action.setBadgeText({ text });
  } catch {}
}

async function setRecordingUi(on) {
  await api.action.setTitle({ title: on ? 'Lensbar: recording (click for controls)' : 'Lensbar' });
  if (!on) await badge('');
}

// ------------------------------------------------------------------ the menu (a rounded card drawn on the page, under the button)

async function openMenu(tab) {
  if (!tab || tab.id == null) return;
  const rec = await getRec();
  if (rec) return openRecCard(tab, rec);
  try {
    await api.scripting.executeScript({ target: { tabId: tab.id }, files: PAGE_SCRIPTS });
    await api.tabs.sendMessage(tab.id, { type: 'menu', canTabCapture: CAN_TAB_CAPTURE });
  } catch (e) {
    // browser pages (settings, new tab, the stores…) can't be drawn on: use the toolbar popup there
    await api.action.setPopup({ popup: 'popup.html' });
    try { await api.action.openPopup(); } catch {}
    setTimeout(async () => { if (!(await getRec())) api.action.setPopup({ popup: '' }); }, 1000);
  }
}

/// While recording: a rounded controls card on the page. The recording pauses first, so the card
/// never shows up in the video, and carries on when the card closes.
async function openRecCard(tab, rec) {
  const wasPaused = !!rec.paused;
  if (!wasPaused) await recCommand('pause');
  try {
    await api.scripting.executeScript({ target: { tabId: tab.id }, files: PAGE_SCRIPTS });
    await api.tabs.sendMessage(tab.id, { type: 'rec-card', rec: { ...(await getRec()), paused: true }, wasPaused });
  } catch (e) {
    if (!wasPaused) await recCommand('resume');
    await api.action.setPopup({ popup: 'popup.html' });
    try { await api.action.openPopup(); } catch {}
    setTimeout(() => api.action.setPopup({ popup: '' }), 1000);
  }
}

api.action.onClicked.addListener(tab => openMenu(tab));

// ------------------------------------------------------------------ running a capture picked in the menu

/// The menu (popup.html) asks for a capture; screenshots and tab recordings run inside the page.
async function runCapture(msg) {
  if (msg.kind === 'rec' && msg.mode === 'screen') return startScreenRecorder(msg.tabId);
  const tabId = msg.tabId;
  try {
    await api.scripting.executeScript({ target: { tabId }, files: PAGE_SCRIPTS });
    await api.tabs.sendMessage(tabId, { type: 'run', kind: msg.kind, mode: msg.mode });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: 'blocked' };
  }
}

// ------------------------------------------------------------------ offscreen document (Chromium recording)

let creatingOffscreen = null;
async function ensureOffscreen() {
  if (!api.offscreen) return;
  const has = api.runtime.getContexts
    ? (await api.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] })).length > 0
    : false;
  if (has) return;
  const create = () => {
    if (!creatingOffscreen) {
      creatingOffscreen = api.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['USER_MEDIA', 'BLOBS'],
        justification: 'Records the tab with MediaRecorder and saves the video.',
      }).finally(() => { creatingOffscreen = null; });
    }
    return creatingOffscreen;
  };
  try {
    await create();
  } catch (e) {
    // "Page failed to load": a leftover recorder page from before (an update, a crash). Clear it and try once more.
    await closeOffscreen();
    await new Promise(r => setTimeout(r, 400));
    await create();
  }
}

async function closeOffscreen() {
  try { if (api.offscreen) await api.offscreen.closeDocument(); } catch {}
}

async function micAllowed() {
  try {
    const p = await navigator.permissions.query({ name: 'microphone' });
    return p.state === 'granted' ? true : p.state === 'denied' || p.state === 'prompt' ? false : null;
  } catch { return null; }   // unknown: let the recorder try, and ask only if it's blocked
}

async function askMic() {
  const url = api.runtime.getURL('mic.html');
  await api.windows.create({ url, type: 'popup', width: 440, height: 330, focused: true });
}

// ------------------------------------------------------------------ messages

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'rec') return false;   // meant for the recorder
  handle(msg, sender).then(sendResponse, e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});

let lastCapture = 0;
async function captureVisible(windowId, format = 'png') {
  // Chromium allows ~2 captures per second
  const wait = lastCapture + 560 - Date.now();
  if (wait > 0) await new Promise(r => setTimeout(r, wait));
  lastCapture = Date.now();
  return api.tabs.captureVisibleTab(windowId, { format, quality: 95 });
}

const pendingDownloads = new Map();   // downloadId -> cleanup

async function handle(msg, sender) {
  const tab = sender.tab;
  switch (msg.type) {
    case 'settings': return getSettings();

    case 'capture':
      return { ok: true, dataUrl: await captureVisible(tab.windowId) };

    case 'capture-page': {
      // Firefox: one-shot capture of the whole document
      if (!api.tabs.captureTab) return { ok: false };
      const dataUrl = await api.tabs.captureTab(tab.id, { rect: msg.rect, scale: msg.scale, format: 'png' });
      return { ok: true, dataUrl };
    }

    case 'save': {
      const s = await getSettings();
      try {
        let url = msg.url;
        if (msg.blob && URL.createObjectURL) {                     // Firefox: the file came along with the message
          url = URL.createObjectURL(msg.blob);
          setTimeout(() => URL.revokeObjectURL(url), 5 * 60 * 1000);
        }
        const id = await download({ url, filename: msg.filename, saveAs: !!s.saveAs });
        if (!s.saveAs) learnRoot.set(id, msg.filename);
        return { ok: true, id };
      } catch (e) {
        return { ok: false, error: String(e && e.message || e) };
      }
    }

    case 'delete-download': {
      try {
        const [d] = await api.downloads.search({ id: msg.id });
        if (d && d.state === 'in_progress') await api.downloads.cancel(msg.id);
        else await api.downloads.removeFile(msg.id);
      } catch {}
      try { await api.downloads.erase({ id: msg.id }); } catch {}
      return { ok: true };
    }

    case 'show-download':
      try { await api.downloads.show(msg.id); } catch {}
      return { ok: true };

    case 'badge':
      await badge(msg.text || '', msg.color || '#3B4558');
      return { ok: true };

    case 'open-options':
      await api.runtime.openOptionsPage();
      return { ok: true };

    case 'mic-check':
      return { ok: true, granted: await micAllowed() };

    case 'ask-mic':
      await askMic();
      return { ok: true };

    case 'rec-start':
      return startTabRecording(tab, msg);

    case 'rec-screen':
      return startScreenRecorder(tab && tab.id, msg.crop);

    case 'run':
      return runCapture(msg);

    case 'probe': {
      // can Lensbar run on this tab? (browser pages and extension stores refuse)
      try {
        await api.scripting.executeScript({ target: { tabId: msg.tabId }, func: () => true });
        return { ok: true, allowed: true };
      } catch (e) {
        return { ok: true, allowed: false };
      }
    }

    case 'can-tab-capture':
      return { ok: true, value: CAN_TAB_CAPTURE };

    // ---- from the recorders
    case 'rec-tick': {
      const rec = await getRec();
      if (!rec) return { ok: true };
      rec.elapsed = msg.elapsed; rec.paused = msg.paused; rec.mic = msg.mic; rec.tabAudio = msg.tabAudio;
      await setRec(rec);
      await badge(msg.paused ? '❚❚' : fmt(msg.elapsed), msg.paused ? '#5B6577' : '#E5484D');
      return { ok: true };
    }
    case 'rec-finished': return finishRecording(msg);
    case 'rec-failed': {
      const rec = await getRec();
      await setRec(null);
      await setRecordingUi(false);
      if (rec && rec.kind === 'tab') { await closeOffscreen(); notifyTab(rec.tabId, { type: 'rec-ended', error: msg.error }); }
      return { ok: true };
    }

    // ---- from the popup
    case 'rec-state': return { ok: true, rec: await getRec() };

    // ---- Firefox: recording made inside the page (after Firefox's own "see your screen" box)
    case 'page-rec-started': {
      const s = await getSettings();
      await setRec({ kind: 'page', tabId: tab && tab.id, mode: 'screen', startedAt: Date.now(), elapsed: 0, paused: false,
                     mic: !!msg.mic, tabAudio: !!msg.tabAudio, micBlocked: !!msg.micBlocked });
      await setRecordingUi(true);
      await badge('0:00');
      return { ok: true };
    }
    case 'page-rec-done': {
      // the WebM comes along with the message; make it an MP4 here, then save it like any recording
      if (msg.discarded || !msg.blob) return finishRecording({ discarded: true, error: msg.error });
      const s = await getSettings();
      let out = msg.blob, ext = 'webm';
      const mp4 = await lensToMp4(msg.blob, { fps: s.fps, quality: s.quality, soundQuality: s.soundQuality,
        onProgress: p => notifyTab(tab && tab.id, { type: 'rec-progress', pct: Math.round(p * 100) }) });
      if (mp4) { out = mp4; ext = 'mp4'; }
      const url = URL.createObjectURL(out);
      setTimeout(() => URL.revokeObjectURL(url), 10 * 60 * 1000);
      return finishRecording({ url, ext });
    }
    case 'rec-command': await recCommand(msg.cmd); return { ok: true };
  }
  return { ok: false, error: 'unknown message' };
}

async function notifyTab(tabId, msg) {
  if (tabId == null) return;
  try { await api.tabs.sendMessage(tabId, msg); } catch {}
}

async function recCommand(cmd) {
  const rec = await getRec();
  if (!rec) return;
  if (rec.kind === 'page') {                                     // Firefox: the recorder lives in that tab
    try { await api.tabs.sendMessage(rec.tabId, { type: 'page-rec-cmd', cmd }); } catch {}
  } else {
    try { await api.runtime.sendMessage({ target: 'rec', cmd }); } catch {}
  }
  if (cmd === 'pause' || cmd === 'resume') { rec.paused = cmd === 'pause'; await setRec(rec); }
}

// ------------------------------------------------------------------ tab / area recording (Chromium)

async function startTabRecording(tab, msg) {
  if (!CAN_TAB_CAPTURE) return { ok: false, error: 'This browser can only record a screen or window.' };
  if (await getRec()) return { ok: false, error: 'Already recording.' };
  const s = await getSettings();
  let streamId;
  try {
    streamId = await api.tabCapture.getMediaStreamId({ targetTabId: tab.id });
  } catch (e) {
    return { ok: false, error: 'Click the Lensbar button on this tab, then choose Record again.' };
  }
  try {
    await ensureOffscreen();
  } catch (e) {
    return { ok: false, error: 'Lensbar\'s recorder didn\'t start. Reload Lensbar on chrome://extensions, then try again.' };
  }
  const res = await api.runtime.sendMessage({
    target: 'rec', cmd: 'start', kind: 'tab', streamId,
    area: msg.area || null, viewport: msg.viewport,
    tabAudio: s.tabAudio, mic: s.mic, fps: s.fps, quality: s.quality, soundQuality: s.soundQuality,
  });
  if (!res || !res.ok) {
    await closeOffscreen();
    return { ok: false, error: (res && res.error) || 'Couldn\'t start recording.' };
  }
  await setRec({ kind: 'tab', tabId: tab.id, mode: msg.area ? 'area' : 'tab', startedAt: Date.now(), elapsed: 0, paused: false, mic: s.mic, tabAudio: s.tabAudio, micBlocked: res.micBlocked });
  await setRecordingUi(true);
  await badge('0:00');
  if (res.micBlocked) askMic();
  return { ok: true };
}

// ------------------------------------------------------------------ screen / window recording (every browser)

async function startScreenRecorder(tabId, crop) {
  if (await getRec()) return { ok: false, error: 'Already recording.' };
  const q = new URLSearchParams();
  // the tab Lensbar was opened on: gets the "Recording saved" note, and (Chrome/Edge) gives the sound, since a
  // browser window has no sound of its own to share: the recorder mixes that tab's sound into the window recording
  if (tabId != null) q.set('from', tabId);
  if (api.desktopCapture && api.tabCapture && tabId != null) q.set('sound', '1');
  if (crop) q.set('crop', JSON.stringify(crop));                 // Firefox: keep only the page / area of the window
  const url = api.runtime.getURL('recorder.html') + (q.toString() ? '?' + q : '');
  if (api.desktopCapture) {
    // Chrome/Edge: the recorder asks for a window straight away (a list of windows only), so the recorder can be small
    await api.windows.create({ url, type: 'popup', width: 420, height: 300, focused: true });
  } else {
    // other browsers: big enough for the browser's "Choose what to share" dialog; it shrinks once recording starts
    await api.windows.create({ url, type: 'popup', width: 820, height: 640, focused: true });
  }
  return { ok: true };
}

// The recorder page tells us when the screen recording actually starts.
api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'screen-started') {
    (async () => {
      const s = await getSettings();
      await setRec({ kind: 'screen', tabId: msg.tabId ?? null, mode: msg.mode || 'screen', startedAt: Date.now(), elapsed: 0, paused: false, mic: msg.mic ?? s.mic, tabAudio: msg.tabAudio ?? s.tabAudio });
      await setRecordingUi(true);
      await badge('0:00');
    })();
  }
  return false;
});

// ------------------------------------------------------------------ saving a recording

function stamp() {
  const d = new Date(), p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

async function finishRecording(msg) {
  const rec = await getRec();
  await setRec(null);
  await setRecordingUi(false);
  const tabId = rec && rec.tabId;
  if (msg.discarded || !msg.url) {
    if (rec && rec.kind === 'tab') await closeOffscreen();
    notifyTab(tabId, { type: 'rec-ended', discarded: !!msg.discarded, error: msg.error });
    return { ok: true };
  }
  const s = await getSettings();
  const folder = cleanFolder(s.recFolder);
  const filename = `${folder ? folder + '/' : ''}Recording_${stamp()}.${msg.ext || 'webm'}`;
  let id = null, error = null;
  try {
    id = await download({ url: msg.url, filename, saveAs: !!s.saveAs });
  } catch (e) { error = String(e && e.message || e); }
  const cleanup = async () => {
    try { await api.runtime.sendMessage({ target: 'rec', cmd: 'release' }); } catch {}
    if (rec && rec.kind === 'tab') await closeOffscreen();
  };
  if (id != null) pendingDownloads.set(id, cleanup); else cleanup();
  if (id != null && !s.saveAs) learnRoot.set(id, filename);
  notifyTab(tabId, { type: 'rec-ended', saved: id != null, downloadId: id, filename: filename.split('/').pop(), folder: s.saveAs ? '' : folder, error });
  return { ok: true, id };
}

/**
 * Saves a file under the name Lensbar picked ("Lensbar/Recording_….mp4").
 * Chrome ignores that name when another extension (a download manager, for example) also listens for downloads,
 * and the file ends up as "76719593-….mp4" in Downloads. Answering onDeterminingFilename ourselves keeps our name.
 */
const wantedNames = new Map();   // url -> filename
function download({ url, filename, saveAs }) {
  wantedNames.set(url, filename);
  setTimeout(() => wantedNames.delete(url), 5 * 60 * 1000);
  return api.downloads.download({ url, filename, saveAs, conflictAction: 'uniquify' });
}
if (api.downloads.onDeterminingFilename) {
  api.downloads.onDeterminingFilename.addListener((item, suggest) => {
    const want = item.byExtensionId === api.runtime.id && (wantedNames.get(item.url) || wantedNames.get(item.finalUrl));
    if (want) { wantedNames.delete(item.url); suggest({ filename: want, conflictAction: 'uniquify' }); }
    else suggest();
  });
}

/**
 * Settings show the real place files go ("C:\Users\you\Downloads\Lensbar"). Browsers don't tell extensions where the
 * Downloads folder is, so it's learned from the first finished save: full path minus the "Lensbar/name.png" part.
 */
const learnRoot = new Map();   // download id -> the relative name it was saved under
api.downloads.onChanged.addListener(async d => {
  if (!learnRoot.has(d.id) || !d.state) return;
  const rel = learnRoot.get(d.id);
  learnRoot.delete(d.id);
  if (d.state.current !== 'complete') return;
  try {
    const [item] = await api.downloads.search({ id: d.id });
    const root = downloadsRoot(item && item.filename, rel);
    if (root) await api.storage.local.set({ dlRoot: root });
  } catch {}
});

/** "C:\Users\me\Downloads\Lensbar\Shot (1).png" + "Lensbar/Shot.png" -> "C:\Users\me\Downloads" */
function downloadsRoot(full, rel) {
  if (!full || !rel) return null;
  const sep = full.includes('\\') ? '\\' : '/';
  const parts = full.split(/[\\/]/), relParts = rel.split('/');
  const dirDepth = relParts.length - 1;                    // folders between Downloads and the file
  const dirs = parts.slice(0, parts.length - 1);
  if (dirs.length <= dirDepth) return null;
  const tail = dirs.slice(dirs.length - dirDepth);
  if (tail.join('/').toLowerCase() !== relParts.slice(0, dirDepth).join('/').toLowerCase()) return null;
  return dirs.slice(0, dirs.length - dirDepth).join(sep) || sep;
}

api.downloads.onChanged.addListener(d => {
  if (!pendingDownloads.has(d.id)) return;
  const st = d.state && d.state.current;
  if (st === 'complete' || st === 'interrupted') {
    const f = pendingDownloads.get(d.id);
    pendingDownloads.delete(d.id);
    setTimeout(f, 1500);
  }
});

// a tab being recorded was closed: stop and save
api.tabs.onRemoved.addListener(async tabId => {
  const rec = await getRec();
  if (rec && rec.kind === 'tab' && rec.tabId === tabId) recCommand('stop');
});

api.runtime.onInstalled.addListener(async () => {
  await setRecordingUi(false);
  await setRec(null);
  try { await api.action.setPopup({ popup: '' }); } catch {}
});

api.runtime.onStartup && api.runtime.onStartup.addListener(async () => {
  await setRecordingUi(false);
  await setRec(null);
});
