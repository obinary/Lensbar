// Lensbar for browsers: background (service worker in Chrome/Edge/Opera/Brave, event page in Firefox).
const api = globalThis.browser ?? globalThis.chrome;
const CAN_TAB_CAPTURE = !!(api.offscreen && api.tabCapture);   // Chromium browsers

const DEFAULTS = {
  tabAudio: true, mic: false, fps: 30, countdown: true,
  imageFormat: 'png', copyShots: true, saveAs: false, lastTab: 'shot', pinned: false,
};

async function getSettings() {
  const s = await api.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...s };
}

// ------------------------------------------------------------------ recording state

async function getRec() {
  const { rec } = await api.storage.session.get('rec');
  return rec || null;
}
async function setRec(rec) {
  if (rec) await api.storage.session.set({ rec });
  else await api.storage.session.remove('rec');
}

function fmt(sec) {
  sec = Math.max(0, Math.floor(sec));
  const m = Math.floor(sec / 60), s = sec % 60;
  return m >= 100 ? `${m}m` : `${m}:${String(s).padStart(2, '0')}`;
}

async function badge(text, color = '#E5484D') {
  try {
    await api.action.setBadgeBackgroundColor({ color });
    if (api.action.setBadgeTextColor) await api.action.setBadgeTextColor({ color: '#FFFFFF' });
    await api.action.setBadgeText({ text });
  } catch {}
}

async function setRecordingUi(on) {
  await api.action.setPopup({ popup: on ? 'popup.html' : '' });
  await api.action.setTitle({ title: on ? 'Lensbar: recording (click for controls)' : 'Lensbar (Alt+Shift+R)' });
  if (!on) await badge('');
}

// ------------------------------------------------------------------ opening the bar

async function openBar(tab) {
  if (!tab || tab.id == null) return;
  const rec = await getRec();
  if (rec) return;   // the toolbar button shows the recording controls instead
  try {
    await api.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    await api.tabs.sendMessage(tab.id, { type: 'toggle-bar', canTabCapture: CAN_TAB_CAPTURE });
  } catch (e) {
    // browser pages (settings, new tab, the web store…) don't allow extensions
    await api.action.setPopup({ popup: 'popup.html?blocked=1' });
    try { await api.action.openPopup(); } catch {}
    setTimeout(() => api.action.setPopup({ popup: '' }), 1500);
  }
}

api.action.onClicked.addListener(tab => openBar(tab));

api.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'open-bar') return;
  const rec = await getRec();
  if (rec) { await recCommand('stop'); return; }
  if (!tab) [tab] = await api.tabs.query({ active: true, currentWindow: true });
  openBar(tab);
});

// ------------------------------------------------------------------ offscreen document (Chromium recording)

let creatingOffscreen = null;
async function ensureOffscreen() {
  if (!api.offscreen) return;
  const has = api.runtime.getContexts
    ? (await api.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] })).length > 0
    : false;
  if (has) return;
  if (!creatingOffscreen) {
    creatingOffscreen = api.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['USER_MEDIA', 'BLOBS'],
      justification: 'Records the tab with MediaRecorder and saves the video.',
    }).finally(() => { creatingOffscreen = null; });
  }
  await creatingOffscreen;
}

async function closeOffscreen() {
  try { if (api.offscreen) await api.offscreen.closeDocument(); } catch {}
}

async function micAllowed() {
  try {
    const p = await navigator.permissions.query({ name: 'microphone' });
    return p.state === 'granted' ? true : p.state === 'denied' || p.state === 'prompt' ? false : null;
  } catch { return null; }   // unknown: let the recorder try, and ask only if it's blocked
}

async function askMic() {
  const url = api.runtime.getURL('mic.html');
  await api.windows.create({ url, type: 'popup', width: 440, height: 330, focused: true });
}

// ------------------------------------------------------------------ messages

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'rec') return false;   // meant for the recorder
  handle(msg, sender).then(sendResponse, e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});

let lastCapture = 0;
async function captureVisible(windowId, format = 'png') {
  // Chromium allows ~2 captures per second
  const wait = lastCapture + 560 - Date.now();
  if (wait > 0) await new Promise(r => setTimeout(r, wait));
  lastCapture = Date.now();
  return api.tabs.captureVisibleTab(windowId, { format, quality: 95 });
}

const pendingDownloads = new Map();   // downloadId -> cleanup

async function handle(msg, sender) {
  const tab = sender.tab;
  switch (msg.type) {
    case 'settings': return getSettings();

    case 'capture':
      return { ok: true, dataUrl: await captureVisible(tab.windowId) };

    case 'capture-page': {
      // Firefox: one-shot capture of the whole document
      if (!api.tabs.captureTab) return { ok: false };
      const dataUrl = await api.tabs.captureTab(tab.id, { rect: msg.rect, scale: msg.scale, format: 'png' });
      return { ok: true, dataUrl };
    }

    case 'save': {
      const s = await getSettings();
      try {
        const id = await api.downloads.download({ url: msg.url, filename: msg.filename, saveAs: !!s.saveAs, conflictAction: 'uniquify' });
        return { ok: true, id };
      } catch (e) {
        return { ok: false, error: String(e && e.message || e) };
      }
    }

    case 'show-download':
      try { await api.downloads.show(msg.id); } catch {}
      return { ok: true };

    case 'badge':
      await badge(msg.text || '', msg.color || '#3B4558');
      return { ok: true };

    case 'open-options':
      await api.runtime.openOptionsPage();
      return { ok: true };

    case 'mic-check':
      return { ok: true, granted: await micAllowed() };

    case 'ask-mic':
      await askMic();
      return { ok: true };

    case 'rec-start':
      return startTabRecording(tab, msg);

    case 'rec-screen':
      return startScreenRecorder();

    // ---- from the recorders
    case 'rec-tick': {
      const rec = await getRec();
      if (!rec) return { ok: true };
      rec.elapsed = msg.elapsed; rec.paused = msg.paused; rec.mic = msg.mic; rec.tabAudio = msg.tabAudio;
      await setRec(rec);
      await badge(msg.paused ? '❚❚' : fmt(msg.elapsed), msg.paused ? '#5B6577' : '#E5484D');
      return { ok: true };
    }
    case 'rec-finished': return finishRecording(msg);
    case 'rec-failed': {
      const rec = await getRec();
      await setRec(null);
      await setRecordingUi(false);
      if (rec && rec.kind === 'tab') { await closeOffscreen(); notifyTab(rec.tabId, { type: 'rec-ended', error: msg.error }); }
      return { ok: true };
    }

    // ---- from the popup
    case 'rec-state': return { ok: true, rec: await getRec() };
    case 'rec-command': await recCommand(msg.cmd); return { ok: true };
  }
  return { ok: false, error: 'unknown message' };
}

async function notifyTab(tabId, msg) {
  if (tabId == null) return;
  try { await api.tabs.sendMessage(tabId, msg); } catch {}
}

async function recCommand(cmd) {
  const rec = await getRec();
  if (!rec) return;
  try { await api.runtime.sendMessage({ target: 'rec', cmd }); } catch {}
}

// ------------------------------------------------------------------ tab / area recording (Chromium)

async function startTabRecording(tab, msg) {
  if (!CAN_TAB_CAPTURE) return { ok: false, error: 'This browser can only record a screen or window.' };
  if (await getRec()) return { ok: false, error: 'Already recording.' };
  const s = await getSettings();
  let streamId;
  try {
    streamId = await api.tabCapture.getMediaStreamId({ targetTabId: tab.id });
  } catch (e) {
    return { ok: false, error: 'Chrome needs you to click the Lensbar button (or press Alt+Shift+R) on this tab first.' };
  }
  await ensureOffscreen();
  const res = await api.runtime.sendMessage({
    target: 'rec', cmd: 'start', kind: 'tab', streamId,
    area: msg.area || null, viewport: msg.viewport,
    tabAudio: s.tabAudio, mic: s.mic, fps: s.fps,
  });
  if (!res || !res.ok) {
    await closeOffscreen();
    return { ok: false, error: (res && res.error) || 'Couldn\'t start recording.' };
  }
  await setRec({ kind: 'tab', tabId: tab.id, mode: msg.area ? 'area' : 'tab', startedAt: Date.now(), elapsed: 0, paused: false, mic: s.mic, tabAudio: s.tabAudio, micBlocked: res.micBlocked });
  await setRecordingUi(true);
  await badge('0:00');
  if (res.micBlocked) askMic();
  return { ok: true };
}

// ------------------------------------------------------------------ screen / window recording (every browser)

async function startScreenRecorder() {
  if (await getRec()) return { ok: false, error: 'Already recording.' };
  const url = api.runtime.getURL('recorder.html');
  await api.windows.create({ url, type: 'popup', width: 420, height: 300, focused: true });
  return { ok: true };
}

// The recorder page tells us when the screen recording actually starts.
api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'screen-started') {
    (async () => {
      const s = await getSettings();
      await setRec({ kind: 'screen', tabId: null, mode: 'screen', startedAt: Date.now(), elapsed: 0, paused: false, mic: msg.mic ?? s.mic, tabAudio: msg.tabAudio ?? s.tabAudio });
      await setRecordingUi(true);
      await badge('0:00');
    })();
  }
  return false;
});

// ------------------------------------------------------------------ saving a recording

function stamp() {
  const d = new Date(), p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

async function finishRecording(msg) {
  const rec = await getRec();
  await setRec(null);
  await setRecordingUi(false);
  const tabId = rec && rec.tabId;
  if (msg.discarded || !msg.url) {
    if (rec && rec.kind === 'tab') await closeOffscreen();
    notifyTab(tabId, { type: 'rec-ended', discarded: !!msg.discarded, error: msg.error });
    return { ok: true };
  }
  const s = await getSettings();
  const filename = `Lensbar/Recording_${stamp()}.${msg.ext || 'webm'}`;
  let id = null, error = null;
  try {
    id = await api.downloads.download({ url: msg.url, filename, saveAs: !!s.saveAs, conflictAction: 'uniquify' });
  } catch (e) { error = String(e && e.message || e); }
  const cleanup = async () => {
    try { await api.runtime.sendMessage({ target: 'rec', cmd: 'release' }); } catch {}
    if (rec && rec.kind === 'tab') await closeOffscreen();
  };
  if (id != null) pendingDownloads.set(id, cleanup); else cleanup();
  notifyTab(tabId, { type: 'rec-ended', saved: id != null, downloadId: id, filename: filename.split('/').pop(), error });
  return { ok: true, id };
}

api.downloads.onChanged.addListener(d => {
  if (!pendingDownloads.has(d.id)) return;
  const st = d.state && d.state.current;
  if (st === 'complete' || st === 'interrupted') {
    const f = pendingDownloads.get(d.id);
    pendingDownloads.delete(d.id);
    setTimeout(f, 1500);
  }
});

// a tab being recorded was closed: stop and save
api.tabs.onRemoved.addListener(async tabId => {
  const rec = await getRec();
  if (rec && rec.kind === 'tab' && rec.tabId === tabId) recCommand('stop');
});

api.runtime.onInstalled.addListener(async () => {
  await setRecordingUi(false);
  await setRec(null);
});

api.runtime.onStartup && api.runtime.onStartup.addListener(async () => {
  await setRecordingUi(false);
  await setRec(null);
});
