const api = globalThis.browser ?? globalThis.chrome;
const $ = id => document.getElementById(id);
const DEFAULTS = { tabAudio: true, mic: false, fps: 30 };
let S = { ...DEFAULTS };
let rec = null, finishing = false;

setHTML($('logo'), LENS_LOGO);
function view(id) { for (const v of document.querySelectorAll('.view')) v.classList.toggle('show', v.id === id); }

async function load() {
  S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  $('sw-audio').classList.toggle('on', S.tabAudio);
  $('sw-mic').classList.toggle('on', S.mic);
}
load();
$('sw-audio').onclick = async () => { S.tabAudio = !S.tabAudio; await api.storage.local.set({ tabAudio: S.tabAudio }); load(); };
$('sw-mic').onclick = async () => { S.mic = !S.mic; await api.storage.local.set({ mic: S.mic }); load(); };

$('go').onclick = async () => {
  $('err').textContent = '';
  let stream;
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: S.fps },
      audio: S.tabAudio,
      systemAudio: 'include', selfBrowserSurface: 'exclude', surfaceSwitching: 'include',
    });
  } catch (e) {
    $('err').textContent = e && e.name === 'NotAllowedError' ? 'Nothing was shared. Try again when you are ready.' : String(e && e.message || e);
    return;
  }
  rec = new LensRecorder();
  rec.onEnded = () => finish(false);   // "Stop sharing" in the browser
  try {
    const r = await rec.start(stream, { tabAudio: S.tabAudio, mic: S.mic, monitor: false, fps: S.fps });
    if (r.micBlocked) $('what').textContent = 'Recording without the microphone (permission was blocked).';
  } catch (e) {
    stream.getTracks().forEach(t => t.stop());
    $('err').textContent = String(e && e.message || e);
    rec = null;
    return;
  }
  api.runtime.sendMessage({ type: 'screen-started', mic: rec.mic, tabAudio: rec.tabAudio }).catch(() => {});
  view('live');
  render();
};

function render() {
  if (!rec) return;
  $('time').textContent = lensFmt(rec.elapsed);
  $('dot').classList.toggle('paused', rec.paused);
  setHTML($('pause'), lensIcon(rec.paused ? 'play' : 'pause'));
  setHTML($('mic'), lensIcon(rec.mic ? 'mic' : 'micOff'));
  $('mic').classList.toggle('off', !rec.mic);
  setHTML($('tabAudio'), lensIcon(rec.tabAudio ? 'speaker' : 'speakerOff'));
  $('tabAudio').classList.toggle('off', !rec.tabAudio);
  setHTML($('discard'), lensIcon('trash'));
  setHTML($('stop'), lensIcon('stop'));
}
setInterval(render, 250);

$('pause').onclick = () => { rec && (rec.paused ? rec.resume() : rec.pause()); render(); };
$('mic').onclick = async () => { if (rec) await rec.setMic(!rec.mic); render(); };
$('tabAudio').onclick = () => { rec && rec.setTabAudio(!rec.tabAudio); render(); };
$('stop').onclick = () => finish(false);
$('discard').onclick = () => { if (confirm('Discard this recording?')) finish(true); };

async function finish(discard) {
  if (!rec || finishing) return;
  finishing = true;
  view('saving');
  if (discard) $('savingText').textContent = 'Discarding…';
  const r = await rec.stop(discard);
  await api.runtime.sendMessage({ type: 'rec-finished', ...r, discarded: !!r.discarded }).catch(() => {});
  if (r.discarded) window.close();
}

// commands from the toolbar popup / shortcut
api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'rec' || !rec) return false;
  switch (msg.cmd) {
    case 'toggle-pause': rec.paused ? rec.resume() : rec.pause(); break;
    case 'toggle-mic': rec.setMic(!rec.mic); break;
    case 'toggle-tabaudio': rec.setTabAudio(!rec.tabAudio); break;
    case 'stop': finish(false); break;
    case 'discard': finish(true); break;
    case 'release': rec.release(); setTimeout(() => window.close(), 300); break;
  }
  render();
  sendResponse({ ok: true });
  return false;
});

// closing the window mid-recording: don't leave the toolbar stuck in "recording"
window.addEventListener('pagehide', () => {
  if (rec && !finishing) api.runtime.sendMessage({ type: 'rec-failed', error: 'The recorder window was closed.' }).catch(() => {});
});
