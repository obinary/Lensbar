const api = globalThis.browser ?? globalThis.chrome;
const $ = id => document.getElementById(id);
const DEFAULTS = { tabAudio: true, mic: false, fps: 30, quality: 'high', soundQuality: 'high' };
let S = { ...DEFAULTS };
let rec = null, finishing = false;

setHTML($('logo'), LENS_LOGO);
function view(id) { for (const v of document.querySelectorAll('.view')) v.classList.toggle('show', v.id === id); }

const params = new URLSearchParams(location.search);
const fromTab = params.get('from') ? Number(params.get('from')) : null;
const cropInfo = params.get('crop') ? JSON.parse(params.get('crop')) : null;   // Firefox: page / area of the window
let surface = null;                                                            // what was shared: window / monitor
if (cropInfo) {
  $('idleTitle').textContent = cropInfo.mode === 'area' ? 'Record an area' : 'Record this tab';
  $('idleSub').textContent = 'In the next step, pick the Firefox window with the website (not this small Lensbar window). Lensbar keeps only '
    + (cropInfo.mode === 'area' ? 'the area you chose' : 'the website') + '. Keep the window where it is while recording.';
}

// Firefox shares no sound with a window or screen recording, so there's nothing to switch
if (!api.desktopCapture && /firefox/i.test(navigator.userAgent)) $('soundRow').style.display = 'none';

let loadReady;
async function load() {
  S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  $('sw-audio').classList.toggle('on', S.tabAudio);
  $('sw-mic').classList.toggle('on', S.mic);
}
loadReady = load();
$('sw-audio').onclick = async () => { S.tabAudio = !S.tabAudio; await api.storage.local.set({ tabAudio: S.tabAudio }); load(); };
$('sw-mic').onclick = async () => { S.mic = !S.mic; await api.storage.local.set({ mic: S.mic }); load(); };

/**
 * Chrome / Edge: shows the browser's list of windows only (no tabs, no screens) and records the one picked —
 * the whole browser window, tabs and address bar included. Browsers always ask which window: an extension
 * can't pick it by itself. No click is needed first, so this runs as soon as the recorder opens.
 */
function chooseWindow() {
  return new Promise(res => api.desktopCapture.chooseDesktopMedia(['window'], id => res(id || null)));
}

/**
 * The website's sound (Chrome/Edge): taken from the tab Lensbar was opened on, straight away (the id expires
 * within seconds). Capturing a tab's sound silences it in the speakers, so it's played back here at once.
 */
let tabSound = null, tabSoundCtx = null;
async function grabTabSound() {
  const tabId = params.get('sound') ? fromTab : null;
  if (!tabId || !api.tabCapture) return;
  try {
    // asked by this page for this page (its own tab id as the consumer), or Chrome won't hand the sound over
    const me = await api.tabs.getCurrent();
    const id = await api.tabCapture.getMediaStreamId({ targetTabId: tabId, consumerTabId: me && me.id });
    tabSound = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: id } }, video: false,
    });
    tabSoundCtx = new AudioContext();
    tabSoundCtx.createMediaStreamSource(tabSound).connect(tabSoundCtx.destination);
  } catch (e) { tabSound = null; }
}
function dropTabSound() {
  if (tabSound) tabSound.getTracks().forEach(t => t.stop());
  if (tabSoundCtx) tabSoundCtx.close().catch(() => {});
  tabSound = null; tabSoundCtx = null;
}

async function showMe() {
  try { const w = await api.windows.getCurrent(); await api.windows.update(w.id, { state: 'normal', focused: true, width: 420, height: 300 }); } catch {}
}

async function startBrowserWindow() {
  await loadReady;
  const sound = grabTabSound();
  const id = await chooseWindow();
  await sound;
  if (!id) { dropTabSound(); window.close(); return; }       // Cancel in the list: nothing to record
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: id, maxWidth: 3840, maxHeight: 2160, maxFrameRate: S.fps } },
    });
  } catch (e) {
    dropTabSound();
    view('idle');
    $('err').textContent = String(e && e.message || e);
    showMe();                                                   // it was minimized: bring it up to show the problem
    return;
  }
  if (tabSound) tabSound.getAudioTracks().forEach(t => stream.addTrack(t));   // window picture + website sound
  begin(stream);
}

$('go').onclick = async () => {
  $('err').textContent = '';
  if (api.desktopCapture) { startBrowserWindow(); return; }
  let stream;
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: S.fps, displaySurface: 'window' },
      audio: S.tabAudio,
      systemAudio: 'include', selfBrowserSurface: 'exclude', surfaceSwitching: 'include', monitorTypeSurfaces: 'exclude',
    });
  } catch (e) {
    $('err').textContent = e && e.name === 'NotAllowedError' ? 'Nothing was shared. Try again when you are ready.' : String(e && e.message || e);
    return;
  }
  begin(stream);
};

async function begin(stream) {
  try { surface = stream.getVideoTracks()[0].getSettings().displaySurface || null; } catch {}
  rec = new LensRecorder();
  rec.onEnded = () => finish(false);   // "Stop sharing" in the browser
  try {
    const r = await rec.start(stream, { tabAudio: S.tabAudio, mic: S.mic, monitor: false, fps: S.fps,
                                        quality: S.quality, soundQuality: S.soundQuality });
    if (r.micBlocked) $('what').textContent = 'Recording without the microphone (permission was blocked).';
    else if (!stream.getAudioTracks().length && !rec.mic)
      $('what').textContent = 'Recording without sound: this browser can\'t share the website\'s sound. Turn on the mic to add your voice.';
    else if (tabSound) $('what').textContent = 'Recording the browser window with the website\'s sound.';
  } catch (e) {
    stream.getTracks().forEach(t => t.stop());
    view('idle');
    $('err').textContent = String(e && e.message || e);
    rec = null;
    showMe();
    return;
  }
  $('tabAudio').style.display = stream.getAudioTracks().length ? '' : 'none';   // a window has no sound to switch
  api.runtime.sendMessage({ type: 'screen-started', mic: rec.mic, tabAudio: rec.tabAudio, tabId: fromTab,
                           mode: cropInfo ? cropInfo.mode : 'screen' }).catch(() => {});
  view('live');
  render();
  try {
    const w = await api.windows.getCurrent();
    if (w.state !== 'minimized') await api.windows.update(w.id, { width: 420, height: 300 });   // (Chrome keeps it minimized)
  } catch {}
}

if (api.desktopCapture) { view('waiting'); startBrowserWindow(); }

function render() {
  if (!rec) return;
  $('time').textContent = lensFmt(rec.elapsed);
  $('dot').classList.toggle('paused', rec.paused);
  setHTML($('pause'), lensIcon(rec.paused ? 'play' : 'pause'));
  setHTML($('mic'), lensIcon(rec.mic ? 'mic' : 'micOff'));
  $('mic').classList.toggle('off', !rec.mic);
  setHTML($('tabAudio'), lensIcon(rec.tabAudio ? 'speaker' : 'speakerOff'));
  $('tabAudio').classList.toggle('off', !rec.tabAudio);
  setHTML($('discard'), lensIcon('trash'));
  setHTML($('stop'), lensIcon('stop'));
}
setInterval(render, 250);

$('pause').onclick = () => { rec && (rec.paused ? rec.resume() : rec.pause()); render(); };
$('mic').onclick = async () => { if (rec) await rec.setMic(!rec.mic); render(); };
$('tabAudio').onclick = () => { rec && rec.setTabAudio(!rec.tabAudio); render(); };
$('stop').onclick = () => finish(false);
$('discard').onclick = () => { if (confirm('Discard this recording?')) finish(true); };

async function finish(discard) {
  if (!rec || finishing) return;
  finishing = true;
  view('saving');
  if (discard) $('savingText').textContent = 'Discarding…';
  let r = await rec.stop(discard);
  dropTabSound();
  // Firefox records WebM: turn it into an MP4 (and keep only the page / area when recording a tab)
  if (!r.discarded && r.url && (r.ext !== 'mp4' || cropInfo)) r = await toMp4(r, rec.blob);
  await api.runtime.sendMessage({ type: 'rec-finished', ...r, discarded: !!r.discarded }).catch(() => {});
  if (r.discarded) window.close();
}

/// Where the page (or area) sits inside the recorded picture, in its pixels. w/h: the recorded picture's size.
function cropRect(w, h) {
  const c = cropInfo, k = c.dpr || 1;
  let x, y;
  if (surface === 'monitor' || (Math.abs(w - c.scr.w * k) < 4 && Math.abs(h - c.scr.h * k) < 4 && surface !== 'window')) {
    x = (c.vp.x - c.scr.x) * k; y = (c.vp.y - c.scr.y) * k;             // the whole screen was shared
  } else {
    const ww = c.win.w * k, wh = c.win.h * k;
    if (w > ww + 2 || h > wh + 2 || w < ww - 60 || h < wh - 60) return null; // another window was picked: keep it all
    const side = Math.max(0, (ww - w) / 2);                             // Windows' invisible resize borders
    x = (c.vp.x - c.win.x) * k - side; y = (c.vp.y - c.win.y) * k;
  }
  let cw = c.vp.w * k, ch = c.vp.h * k;
  if (c.area) { x += c.area.x * k; y += c.area.y * k; cw = c.area.w * k; ch = c.area.h * k; }
  x = Math.max(0, Math.round(x)); y = Math.max(0, Math.round(y));
  cw = Math.min(Math.round(cw), w - x) & ~1; ch = Math.min(Math.round(ch), h - y) & ~1;
  return cw >= 16 && ch >= 16 ? { left: x, top: y, width: cw, height: ch } : null;
}

/// WebM -> MP4 (see convert.js), cropped to the page / area when recording a tab in Firefox.
async function toMp4(r, blob) {
  $('savingText').textContent = 'Making an MP4…';
  const mp4 = await lensToMp4(blob, {
    fps: S.fps, quality: S.quality, soundQuality: S.soundQuality,
    cropFor: cropInfo ? cropRect : null,
    onProgress: p => { $('savingText').textContent = `Making an MP4… ${Math.round(p * 100)}%`; },
  });
  if (!mp4) return r;
  URL.revokeObjectURL(r.url);
  return { url: URL.createObjectURL(mp4), ext: 'mp4', size: mp4.size };
}

// commands from the toolbar popup / shortcut
api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'rec' || !rec) return false;
  switch (msg.cmd) {
    case 'toggle-pause': rec.paused ? rec.resume() : rec.pause(); break;
    case 'pause': rec.pause(); break;
    case 'resume': rec.resume(); break;
    case 'toggle-mic': rec.setMic(!rec.mic); break;
    case 'toggle-tabaudio': rec.setTabAudio(!rec.tabAudio); break;
    case 'stop': finish(false); break;
    case 'discard': finish(true); break;
    case 'release': rec.release(); setTimeout(() => window.close(), 300); break;
  }
  render();
  sendResponse({ ok: true, paused: rec.paused });
  return false;
});

// closing the window mid-recording: don't leave the toolbar stuck in "recording"
window.addEventListener('pagehide', () => {
  if (rec && !finishing) api.runtime.sendMessage({ type: 'rec-failed', error: 'The recorder window was closed.' }).catch(() => {});
});
