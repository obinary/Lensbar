// Chromium only: records the tab (or an area of it) from a tabCapture stream id.
let rec = null;
let busy = false;

lensApi.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'rec') return false;
  run(msg).then(sendResponse, e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});

async function run(msg) {
  switch (msg.cmd) {
    case 'start': {
      if (rec) return { ok: false, error: 'Already recording.' };
      const v = msg.viewport || { w: 1920, h: 1080, dpr: 1 };
      const maxW = Math.min(3840, Math.round(v.w * (v.dpr || 1)));
      const maxH = Math.min(2160, Math.round(v.h * (v.dpr || 1)));
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: msg.streamId } },
        video: {
          mandatory: {
            chromeMediaSource: 'tab', chromeMediaSourceId: msg.streamId,
            maxWidth: maxW, maxHeight: maxH, minWidth: Math.round(maxW / 2), minHeight: Math.round(maxH / 2),
            maxFrameRate: msg.fps || 30,
          },
        },
      });
      rec = new LensRecorder();
      rec.onEnded = () => finish(false);
      const r = await rec.start(stream, { area: msg.area, viewport: v, tabAudio: msg.tabAudio, mic: msg.mic, monitor: true, fps: msg.fps });
      return { ok: true, micBlocked: r.micBlocked };
    }
    case 'pause': rec && rec.pause(); return { ok: true };
    case 'resume': rec && rec.resume(); return { ok: true };
    case 'toggle-pause': rec && (rec.paused ? rec.resume() : rec.pause()); return { ok: true };
    case 'toggle-mic': if (rec) { const ok = await rec.setMic(!rec.mic); if (!ok) lensApi.runtime.sendMessage({ type: 'ask-mic' }).catch(() => {}); } return { ok: true };
    case 'toggle-tabaudio': rec && rec.setTabAudio(!rec.tabAudio); return { ok: true };
    case 'stop': finish(false); return { ok: true };
    case 'discard': finish(true); return { ok: true };
    case 'release': if (rec) { rec.release(); rec = null; } return { ok: true };
  }
  return { ok: false };
}

async function finish(discard) {
  if (!rec || busy) return;
  busy = true;
  try {
    const r = await rec.stop(discard);
    await lensApi.runtime.sendMessage({ type: 'rec-finished', ...r, discarded: !!r.discarded });
    if (r.discarded) rec = null;
  } catch (e) {
    lensApi.runtime.sendMessage({ type: 'rec-failed', error: String(e && e.message || e) }).catch(() => {});
    rec = null;
  } finally {
    busy = false;
  }
}
