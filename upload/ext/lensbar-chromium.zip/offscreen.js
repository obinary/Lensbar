// Chromium only: records the tab (or an area of it) from a tabCapture stream id.
let rec = null;
let busy = false;

lensApi.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'rec') return false;
  run(msg).then(sendResponse, e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});

async function run(msg) {
  switch (msg.cmd) {
    case 'start': {
      if (rec) return { ok: false, error: 'Already recording.' };
      const v = msg.viewport || { w: 1920, h: 1080, dpr: 1 };
      const maxW = Math.min(3840, Math.round(v.w * (v.dpr || 1)));
      const maxH = Math.min(2160, Math.round(v.h * (v.dpr || 1)));
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: msg.streamId } },
        video: {
          mandatory: {
            chromeMediaSource: 'tab', chromeMediaSourceId: msg.streamId,
            // Chrome may lower the picture size when the computer is busy: Best keeps it close to full size
            maxWidth: maxW, maxHeight: maxH,
            minWidth: Math.round(maxW * (msg.quality === 'best' ? 0.9 : 0.5)), minHeight: Math.round(maxH * (msg.quality === 'best' ? 0.9 : 0.5)),
            maxFrameRate: msg.fps || 30,
          },
        },
      });
      rec = new LensRecorder();
      rec.onEnded = () => finish(false);
      const r = await rec.start(stream, { area: msg.area, viewport: v, tabAudio: msg.tabAudio, mic: msg.mic, monitor: true, fps: msg.fps,
                                        quality: msg.quality, soundQuality: msg.soundQuality });
      return { ok: true, micBlocked: r.micBlocked };
    }
    case 'pause': rec && rec.pause(); return { ok: true };
    case 'resume': rec && rec.resume(); return { ok: true };
    case 'toggle-pause': rec && (rec.paused ? rec.resume() : rec.pause()); return { ok: true };
    case 'toggle-mic': if (rec) { const ok = await rec.setMic(!rec.mic); if (!ok) lensApi.runtime.sendMessage({ type: 'ask-mic' }).catch(() => {}); } return { ok: true };
    case 'toggle-tabaudio': rec && rec.setTabAudio(!rec.tabAudio); return { ok: true };
    case 'stop': finish(false); return { ok: true };
    case 'discard': finish(true); return { ok: true };
    case 'release':
      if (rec) { rec.release(); rec = null; }
      if (relayUrl) { URL.revokeObjectURL(relayUrl); relayUrl = null; }
      return { ok: true };
  }
  return { ok: false };
}

/**
 * Chrome "record the whole browser window": the recording runs in the web page that opened Chrome's window list
 * (only that page may use the window's picture). Each second's piece of video comes here as it's made, so if the
 * page is left or reloaded, everything recorded until then is still saved.
 */
let relayUrl = null;
lensApi.runtime.onConnect.addListener(port => {
  if (port.name !== 'lens-page-rec') return;
  const parts = [];
  let meta = { mime: 'video/webm', ext: 'webm' }, done = false;
  const save = async (discard, cut) => {
    if (done) return;
    done = true;
    if (discard || !parts.length) { lensApi.runtime.sendMessage({ type: 'rec-finished', discarded: true }).catch(() => {}); return; }
    const blob = new Blob(parts, { type: meta.mime.split(';')[0] });
    parts.length = 0;
    if (relayUrl) URL.revokeObjectURL(relayUrl);
    relayUrl = URL.createObjectURL(blob);
    lensApi.runtime.sendMessage({ type: 'rec-finished', url: relayUrl, ext: meta.ext, size: blob.size, cut: !!cut }).catch(() => {});
  };
  port.onMessage.addListener(m => {
    if (m.meta) meta = m.meta;
    else if (m.chunk) parts.push(fromBase64(m.chunk));
    else if (m.done) save(!!m.discard, false);
  });
  port.onDisconnect.addListener(() => save(false, true));   // the page went away mid-recording
});
function fromBase64(b64) {
  const bin = atob(b64), u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function finish(discard) {
  if (!rec || busy) return;
  busy = true;
  try {
    const r = await rec.stop(discard);
    await lensApi.runtime.sendMessage({ type: 'rec-finished', ...r, discarded: !!r.discarded });
    if (r.discarded) rec = null;
  } catch (e) {
    lensApi.runtime.sendMessage({ type: 'rec-failed', error: String(e && e.message || e) }).catch(() => {});
    rec = null;
  } finally {
    busy = false;
  }
}
