// Lensbar recording engine, shared by the tab recorder (offscreen document) and the screen recorder page.
// Mixes the captured sound and the microphone (each can be switched on/off live), optionally crops the
// video to an area, and records with MediaRecorder (MP4 when the browser supports it, otherwise WebM).
// var (not const / class): Firefox loads this into web pages with Lensbar's menu, maybe more than once
var lensApi = globalThis.browser ?? globalThis.chrome;

var LensRecorder = class LensRecorder {
  constructor() {
    this.recorder = null;
    this.chunks = [];
    this.streams = [];
    this.ctx = null;
    this.tabGain = null;
    this.micGain = null;
    this.micStream = null;
    this.elapsedMs = 0;
    this.runStart = 0;
    this.paused = false;
    this.discard = false;
    this.tickTimer = null;
    this.url = null;
    this.mic = false;
    this.tabAudio = true;
    this.monitor = false;
  }

  static pickMime() {
    const types = [
      // avc1 plays everywhere (Windows' Media Player / Photos show "avc3" files with green, smeared frames).
      // It can't take a picture-size change mid-recording, so every frame is kept at one size (see keepSize).
      ...(LensRecorder.canKeepSize ? ['video/mp4;codecs=avc1.640033,mp4a.40.2', 'video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2'] : []),
      'video/mp4;codecs=avc3.640028,mp4a.40.2', 'video/mp4;codecs=avc3,mp4a.40.2',
      'video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4',
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm',
    ];
    for (const t of types) if (window.MediaRecorder && MediaRecorder.isTypeSupported(t)) return t;
    return '';
  }

  /// Bits per second for the picture: grows with size and frame rate. 1080p at 30 fps:
  /// Standard ≈ 5 Mbps, High ≈ 10 Mbps, Best ≈ 19 Mbps (60 fps: about double).
  static videoBitrate(px, fps, quality) {
    const q = { standard: [0.08, 2.5e6, 12e6], high: [0.16, 5e6, 30e6], best: [0.3, 8e6, 60e6] }[quality] || [0.16, 5e6, 30e6];
    return Math.round(Math.max(q[1], Math.min(q[2], px * Math.max(24, fps) * q[0])));
  }

  static get canKeepSize() {
    return !!(window.MediaStreamTrackProcessor && window.MediaStreamTrackGenerator && window.OffscreenCanvas && window.VideoFrame);
  }

  get elapsed() {
    return (this.elapsedMs + (this.paused || !this.runStart ? 0 : performance.now() - this.runStart)) / 1000;
  }

  /// source: a MediaStream with a video track and (maybe) an audio track.
  /// monitor: play the captured sound back (tab capture mutes the tab otherwise).
  async start(source, { area = null, viewport = null, tabAudio = true, mic = false, monitor = false, fps = 30,
                        quality = 'high', soundQuality = 'high' } = {}) {
    this.streams.push(source);
    this.tabAudio = tabAudio;
    this.monitor = monitor;
    let video = source.getVideoTracks()[0];
    if (!video) throw new Error('No video to record.');

    if (area && viewport && window.MediaStreamTrackProcessor && window.MediaStreamTrackGenerator) {
      video = this.crop(video, area, viewport);
    }
    if (LensRecorder.canKeepSize) video = this.keepSize(video);

    // ---- sound: captured audio + microphone -> one track
    this.ctx = new AudioContext({ sampleRate: 48000 });
    const dest = this.ctx.createMediaStreamDestination();
    const audioTracks = source.getAudioTracks();
    if (audioTracks.length) {
      const src = this.ctx.createMediaStreamSource(new MediaStream(audioTracks));
      if (monitor) src.connect(this.ctx.destination);       // keep hearing the tab
      this.tabGain = this.ctx.createGain();
      this.tabGain.gain.value = tabAudio ? 1 : 0;
      src.connect(this.tabGain).connect(dest);
    }
    this.micGain = this.ctx.createGain();
    this.micGain.gain.value = 0;
    this.micGain.connect(dest);
    let micBlocked = false;
    if (mic) micBlocked = !(await this.setMic(true));

    const tracks = [video, ...dest.stream.getAudioTracks()];
    const out = new MediaStream(tracks);
    const mimeType = LensRecorder.pickMime();
    this.mime = mimeType || 'video/webm';
    // the picture size being recorded: the area, or the whole tab / window
    const src = source.getVideoTracks()[0].getSettings ? source.getVideoTracks()[0].getSettings() : {};
    let px = (src.width || 1920) * (src.height || 1080);
    if (area && viewport && viewport.w) {
      const k = (src.width || viewport.w * (viewport.dpr || 1)) / viewport.w;
      px = Math.max(1, area.w * k) * Math.max(1, area.h * k);
    }
    const bitrate = LensRecorder.videoBitrate(px, fps, quality);
    const audioBitrate = soundQuality === 'standard' ? 128000 : 192000;
    // a key frame every 2 s: smooth seeking, and a damaged stretch can't smear for long
    this.recorder = new MediaRecorder(out, { mimeType: mimeType || undefined, videoBitsPerSecond: bitrate, audioBitsPerSecond: audioBitrate,
                                             videoKeyFrameIntervalDuration: 2000 });
    this.recorder.ondataavailable = e => { if (e.data && e.data.size) this.chunks.push(e.data); };
    this.stopped = new Promise(res => { this.recorder.onstop = res; });
    // if the source ends (tab closed, sharing stopped), finish by itself
    source.getVideoTracks()[0].addEventListener('ended', () => this.onEnded && this.onEnded());
    this.recorder.start(1000);
    this.runStart = performance.now();
    this.tickTimer = setInterval(() => this.tick(), 1000);
    this.tick();
    return { micBlocked };
  }

  crop(track, area, viewport) {
    const processor = new MediaStreamTrackProcessor({ track });
    const generator = new MediaStreamTrackGenerator({ kind: 'video' });
    const transformer = new TransformStream({
      transform(frame, controller) {
        try {
          const kx = frame.displayWidth / viewport.w, ky = frame.displayHeight / viewport.h;
          let x = Math.round(area.x * kx) & ~1, y = Math.round(area.y * ky) & ~1;
          let w = Math.round(area.w * kx) & ~1, h = Math.round(area.h * ky) & ~1;
          x = Math.max(0, Math.min(x, frame.codedWidth - 2));
          y = Math.max(0, Math.min(y, frame.codedHeight - 2));
          w = Math.max(2, Math.min(w, frame.codedWidth - x) & ~1);
          h = Math.max(2, Math.min(h, frame.codedHeight - y) & ~1);
          controller.enqueue(new VideoFrame(frame, { visibleRect: { x, y, width: w, height: h }, displayWidth: w, displayHeight: h }));
        } catch (e) { /* skip a bad frame */ }
        frame.close();
      },
    });
    processor.readable.pipeThrough(transformer).pipeTo(generator.writable).catch(() => {});
    return generator;
  }

  /// Keeps every frame the size of the first one (a resized window or zoomed tab is scaled to fit, with black edges),
  /// so the file never changes picture size mid-way: players handle that badly, and MP4 (avc1) can't store it.
  keepSize(track) {
    const processor = new MediaStreamTrackProcessor({ track });
    const generator = new MediaStreamTrackGenerator({ kind: 'video' });
    let W = 0, H = 0, canvas = null, g = null;
    const transformer = new TransformStream({
      transform(frame, controller) {
        const fw = frame.displayWidth, fh = frame.displayHeight;
        if (!W) { W = Math.max(2, fw & ~1); H = Math.max(2, fh & ~1); }
        if (fw === W && fh === H) { controller.enqueue(frame); return; }
        try {
          if (!canvas) { canvas = new OffscreenCanvas(W, H); g = canvas.getContext('2d'); }
          g.fillStyle = '#000';
          g.fillRect(0, 0, W, H);
          const k = Math.min(W / fw, H / fh), dw = Math.round(fw * k), dh = Math.round(fh * k);
          g.drawImage(frame, Math.round((W - dw) / 2), Math.round((H - dh) / 2), dw, dh);
          const init = { timestamp: frame.timestamp };
          if (frame.duration) init.duration = frame.duration;
          controller.enqueue(new VideoFrame(canvas, init));
        } catch (e) { /* skip a bad frame */ }
        frame.close();
      },
    });
    processor.readable.pipeThrough(transformer).pipeTo(generator.writable).catch(() => {});
    return generator;
  }

  async setMic(on) {
    this.mic = on;
    if (on && !this.micStream) {
      try {
        this.micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
        this.streams.push(this.micStream);
        this.ctx.createMediaStreamSource(this.micStream).connect(this.micGain);
      } catch (e) {
        this.mic = false;
        this.tick();
        return false;
      }
    }
    if (this.micGain) this.micGain.gain.value = on ? 1 : 0;
    this.tick();
    return true;
  }

  setTabAudio(on) {
    this.tabAudio = on;
    if (this.tabGain) this.tabGain.gain.value = on ? 1 : 0;
    this.tick();
  }

  pause() {
    if (!this.recorder || this.paused || this.recorder.state !== 'recording') return;
    this.recorder.pause();
    this.elapsedMs += performance.now() - this.runStart;
    this.paused = true;
    this.tick();
  }

  resume() {
    if (!this.recorder || !this.paused) return;
    this.recorder.resume();
    this.runStart = performance.now();
    this.paused = false;
    this.tick();
  }

  tick() {
    try {
      lensApi.runtime.sendMessage({ type: 'rec-tick', elapsed: this.elapsed, paused: this.paused, mic: this.mic, tabAudio: this.tabAudio })
        .catch(() => {});
    } catch {}
  }

  /// Stops and returns { url, ext } (or { discarded: true }).
  async stop(discard = false) {
    this.discard = discard;
    clearInterval(this.tickTimer);
    if (!this.recorder) return { discarded: true };
    if (this.recorder.state !== 'inactive') {
      if (this.paused) this.recorder.resume();
      this.recorder.stop();
    }
    await this.stopped;
    this.streams.forEach(s => s.getTracks().forEach(t => t.stop()));
    try { await this.ctx.close(); } catch {}
    if (discard || !this.chunks.length) { this.chunks = []; return { discarded: true }; }
    const blob = new Blob(this.chunks, { type: this.mime.split(';')[0] });
    this.chunks = [];
    this.url = URL.createObjectURL(blob);
    this.blob = blob;
    return { url: this.url, ext: this.mime.startsWith('video/mp4') ? 'mp4' : 'webm', size: blob.size };
  }

  release() {
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = null;
  }
};
