// Lensbar: turns a WebM recording (Firefox's only format) into an MP4 with Mediabunny, using the browser's own
// encoders. Shared by the recorder window and Firefox's background page. Keeps the WebM if that isn't possible.
// var (not const): this file can be loaded more than once into the same page.
var lensToMp4 = async function (blob, { fps = 30, quality = 'high', soundQuality = 'high', cropFor = null, onProgress = null } = {}) {
  if (!blob || !globalThis.VideoEncoder) return null;
  try {
    const MB = await import('./lib/mediabunny.min.mjs');
    const input = new MB.Input({ source: new MB.BlobSource(blob), formats: MB.ALL_FORMATS });
    const vt = await input.getPrimaryVideoTrack();
    if (!vt) return null;
    const W = await vt.getDisplayWidth(), H = await vt.getDisplayHeight();
    const crop = cropFor ? cropFor(W, H) : null;                // part of the picture to keep, or null for all
    // H.264 plays everywhere; VP9 in an MP4 is the fallback where the browser can't make H.264
    const vcodec = (await MB.canEncodeVideo('avc')) ? 'avc' : (await MB.canEncodeVideo('vp9')) ? 'vp9' : null;
    if (!vcodec) return null;
    const outW = crop ? crop.width : W, outH = crop ? crop.height : H;
    const per = { standard: [0.08, 2.5e6, 12e6], high: [0.16, 5e6, 30e6], best: [0.3, 8e6, 60e6] }[quality] || [0.16, 5e6, 30e6];
    const video = { codec: vcodec, bitrate: Math.round(Math.max(per[1], Math.min(per[2], outW * outH * Math.max(24, fps) * per[0]))) };
    if (crop) video.crop = crop;
    const hasAudio = (await input.getAudioTracks()).length > 0;
    // AAC plays everywhere; where the browser can't make AAC, the recorded Opus sound goes into the MP4 as it is
    const abr = soundQuality === 'standard' ? 128000 : 192000;
    const tries = (await MB.canEncodeAudio('aac')) ? [{ codec: 'aac', bitrate: abr }, {}] : [{}];
    let conv = null, output = null;
    for (const audio of tries) {
      output = new MB.Output({ format: new MB.Mp4OutputFormat({ fastStart: 'in-memory' }), target: new MB.BufferTarget() });
      const c = await MB.Conversion.init({ input, output, video, audio, showWarnings: false });
      const lostSound = hasAudio && c.discardedTracks.some(d => d.track.type === 'audio');
      if (c.isValid && !lostSound) { conv = c; break; }
    }
    if (!conv) return null;                                     // keep the WebM rather than lose the sound
    if (onProgress) conv.onProgress = onProgress;
    await conv.execute();
    return new Blob([output.target.buffer], { type: 'video/mp4' });
  } catch (e) {
    console.warn('Lensbar: MP4 conversion failed, keeping WebM', e);
    return null;
  }
};
