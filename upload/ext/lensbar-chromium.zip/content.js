// Lensbar for browsers: the capture bar and everything that happens inside the page.
(() => {
  if (window.__lensbar) return;
  window.__lensbar = true;

  const api = globalThis.browser ?? globalThis.chrome;
  function setHTML(el, str) {
    // builds markup through DOMParser (no innerHTML), then moves the nodes in
    const doc = new DOMParser().parseFromString(`<body>${str}</body>`, 'text/html');
    el.replaceChildren(...Array.from(doc.body.childNodes).map(n => document.importNode(n, true)));
  }
  const DEFAULTS = {
    tabAudio: true, mic: false, fps: 30, countdown: true,
    imageFormat: 'png', copyShots: true, saveAs: false, lastTab: 'shot', pinned: false,
    shotFolder: 'Lensbar', recFolder: 'Lensbar',
  };
  /** A folder inside Downloads, made safe for the downloads API ("Work/Shots" is fine; "..", "C:" and odd characters are not). */
  function cleanFolder(f) {
    const parts = String(f || '').replace(/\\/g, '/').split('/')
      .map(p => p.replace(/[<>:"|?*\u0000-\u001f]/g, '').replace(/^[. ]+|[. ]+$/g, '').trim())
      .filter(p => p && p !== '..' && p !== '.');
    return parts.join('/').slice(0, 120);
  }

  let S = { ...DEFAULTS };
  let canTabCapture = true;
  // Firefox can't record a tab directly, but it knows where the page sits on screen, so Lensbar records the
  // Firefox window and keeps only the website (or the chosen area) when it makes the MP4.
  const canCropRecord = typeof window.mozInnerScreenX === 'number';

  const send = msg => api.runtime.sendMessage(msg).catch(e => ({ ok: false, error: String(e && e.message || e) }));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const frame2 = () => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

  // ------------------------------------------------------------------ geometry (same as the desktop bar)
  const G = {
    W: 434, H: 87, ear: 20, radius: 20,
    seg: { x: 114, y: 8, w: 206, h: 26 },
    sys: { x: 30, y: 10 }, mic: { x: 56, y: 10 }, pin: { x: 82, y: 10 },
    more: { x: 343, y: 10 }, close: { x: 369, y: 10 }, ib: 22,
    modes: { x: 117, y: 40, w: 64, h: 38, gap: 4 },
    tab: { along: 88, depth: 34, earAlong: 13, earDepth: 11, radius: 13, logo: 16 },
  };

  function notchPath(w, h, ew, ehIn, rIn, ox) {
    const ke = 0.62, kc = 0.62;
    const eh = Math.max(0.5, Math.min(ehIn, h - 0.5));
    const r = Math.max(0.5, Math.min(rIn, Math.min(h - eh, (w - 2 * ew) / 2)));
    const P = (x, y) => `${(x + ox).toFixed(2)} ${y.toFixed(2)}`;
    let d = `M${P(0, 0)}L${P(w, 0)}`;
    d += `C${P(w - ke * ew, 0)} ${P(w - ew, eh - ke * eh)} ${P(w - ew, eh)}`;
    if (h - r > eh + 0.01) d += `L${P(w - ew, h - r)}`;
    d += `C${P(w - ew, h - r + kc * r)} ${P(w - ew - r + kc * r, h)} ${P(w - ew - r, h)}`;
    d += `L${P(ew + r, h)}`;
    d += `C${P(ew + r - kc * r, h)} ${P(ew, h - r + kc * r)} ${P(ew, h - r)}`;
    if (h - r > eh + 0.01) d += `L${P(ew, eh)}`;
    d += `C${P(ew, eh - ke * eh)} ${P(ke * ew, 0)} ${P(0, 0)}Z`;
    return d;
  }

  // ------------------------------------------------------------------ icons (24×24, stroked)
  function gearPath() {
    const cx = 12, cy = 12, ro = 9.3, ri = 7.1, n = 8;
    let d = '';
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * Math.PI * 2, step = Math.PI * 2 / n;
      const pts = [[a0 - step * 0.18, ri], [a0 - step * 0.12, ro], [a0 + step * 0.12, ro], [a0 + step * 0.18, ri], [a0 + step * 0.5, ri]];
      for (const [a, r] of pts) {
        const x = (cx + r * Math.cos(a)).toFixed(2), y = (cy + r * Math.sin(a)).toFixed(2);
        d += (d ? 'L' : 'M') + x + ' ' + y;
      }
    }
    return d + 'Z';
  }
  const I = {
    speaker: '<path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6"/><path d="M18 6.5a7.8 7.8 0 0 1 0 11"/>',
    speakerOff: '<path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4z"/><path d="M16 9.5l5 5"/><path d="M21 9.5l-5 5"/>',
    mic: '<rect x="9" y="3" width="6" height="11.5" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0"/><path d="M12 18v3"/>',
    micOff: '<rect x="9" y="3" width="6" height="11.5" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0"/><path d="M12 18v3"/><path d="M4 4l16 16"/>',
    pin: '<path d="M9 3.5h6"/><path d="M10 3.5v5.3L7 12.5h10l-3-3.7V3.5"/><path d="M12 12.5v8"/>',
    pinOn: '<path d="M9 3.5h6"/><path d="M10 3.5v5.3L7 12.5h10l-3-3.7V3.5z" fill="currentColor"/><path d="M12 12.5v8"/>',
    gear: `<path d="${gearPath()}"/><circle cx="12" cy="12" r="3"/>`,
    close: '<path d="M6.5 6.5l11 11"/><path d="M17.5 6.5l-11 11"/>',
    record: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.4" fill="currentColor" stroke="none"/>',
    camera: '<path d="M4 8.5a2 2 0 0 1 2-2h2.2l1.5-2h4.6l1.5 2H18a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="12.6" r="3.3"/>',
    tab: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3 9.5h18"/><path d="M6.5 7.25h.01"/><path d="M9 7.25h.01"/>',
    area: '<path d="M4 8V6a2 2 0 0 1 2-2h2"/><path d="M16 4h2a2 2 0 0 1 2 2v2"/><path d="M20 16v2a2 2 0 0 1-2 2h-2"/><path d="M8 20H6a2 2 0 0 1-2-2v-2"/><path d="M11 4h2"/><path d="M11 20h2"/><path d="M4 11v2"/><path d="M20 11v2"/>',
    screen: '<rect x="3" y="4.5" width="18" height="12" rx="2"/><path d="M9 20h6"/><path d="M12 16.5V20"/>',
    browser: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M3 8.8h18"/><path d="M6.2 6.65h.01"/><path d="M8.6 6.65h.01"/><path d="M10.2 12.2H7.6v2.6"/><path d="M13.8 16.6h2.6V14"/>',
    visible: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M8 9.5h8"/><path d="M8 12.5h8"/><path d="M8 15.5h5"/>',
    fullpage: '<rect x="6" y="2.5" width="12" height="19" rx="2"/><path d="M12 7v9"/><path d="M9 13l3 3 3-3"/>',
    trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.8h5V7"/><path d="M6.5 7l1 12.5h9l1-12.5"/><path d="M10.2 10.5v6"/><path d="M13.8 10.5v6"/>',
    pause: '<rect x="6.5" y="5" width="3.8" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.7" y="5" width="3.8" height="14" rx="1.2" fill="currentColor" stroke="none"/>',
    play: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor" stroke="none"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor" stroke="none"/>',
  };
  const svg = (name, size = 16) =>
    `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${I[name]}</svg>`;
  const LOGO = `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round">
    <path d="M1.9 6.1V3.5Q1.9 1.9 3.5 1.9H6.1"/><path d="M9.9 1.9h2.6q1.6 0 1.6 1.6v2.6"/><path d="M14.1 9.9v2.6q0 1.6-1.6 1.6H9.9"/><path d="M6.1 14.1H3.5q-1.6 0-1.6-1.6V9.9"/>
    <circle cx="8" cy="8" r="2" fill="currentColor" stroke="none"/></svg>`;

  const MODES = {
    rec: [
      { id: 'tab', icon: 'tab', tip: 'Record this tab' },
      { id: 'area', icon: 'area', tip: 'Record an area' },
      { id: 'screen', icon: 'browser', tip: 'Record the whole browser window' },
    ],
    shot: [
      { id: 'visible', icon: 'visible', tip: 'Visible part' },
      { id: 'area', icon: 'area', tip: 'Select an area' },
      { id: 'full', icon: 'fullpage', tip: 'Full page, top to bottom' },
    ],
  };

  // ------------------------------------------------------------------ DOM

  const fonts = document.createElement('style');
  fonts.textContent = `
    @font-face{font-family:'Lensbar Inter';font-weight:600;src:url('${api.runtime.getURL('fonts/Inter-SemiBold.ttf')}') format('truetype')}
    @font-face{font-family:'Lensbar Tight';font-weight:500;src:url('${api.runtime.getURL('fonts/InterTight-Medium.ttf')}') format('truetype')}
    @font-face{font-family:'Lensbar Tight';font-weight:700;src:url('${api.runtime.getURL('fonts/InterTight-Bold.ttf')}') format('truetype')}`;
  (document.head || document.documentElement).appendChild(fonts);

  const host = document.createElement('lensbar-ui');
  // all:initial leaves out direction, so right-to-left sites (Arabic, Hebrew…) would mirror the whole menu: set it too
  host.style.cssText = 'all:initial;direction:ltr;unicode-bidi:isolate;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'closed' });
  setHTML(root, `
  <style>
    *{box-sizing:border-box}
    .wrap{position:fixed;top:0;left:50%;width:${G.W}px;height:${G.H}px;margin-left:-${G.W / 2}px;pointer-events:none;
      font-family:'Lensbar Tight',system-ui,-apple-system,'Segoe UI',sans-serif;z-index:2147483647;-webkit-font-smoothing:antialiased}
    .wrap.hidden{display:none}
    svg.shape{position:absolute;left:0;top:0;overflow:visible}
    svg.shape path{fill:#0F1116;pointer-events:auto}
    .content{position:absolute;inset:0}
    .content.off *{pointer-events:none!important}
    .btn{position:absolute;width:${G.ib}px;height:${G.ib}px;display:flex;align-items:center;justify-content:center;
      color:#C2C2C2;pointer-events:auto;cursor:pointer;border:0;background:none;padding:0;transition:color .12s}
    .btn:hover{color:#fff}.btn:active{color:#A6A6A6}
    .btn.off{color:#696969}.btn.off:hover{color:#C2C2C2}
    .btn.on{color:#fff}
    .seg{position:absolute;left:${G.seg.x}px;top:${G.seg.y}px;width:${G.seg.w}px;height:${G.seg.h}px;border-radius:13px;background:#323A46;pointer-events:auto}
    .pill{position:absolute;top:2px;left:2px;width:${G.seg.w / 2 - 4}px;height:${G.seg.h - 4}px;border-radius:11px;background:#ECECEC;
      transition:transform .22s cubic-bezier(.65,0,.35,1),background-color .22s}
    .pill.moving{background:#8C919B}
    .seg.shot .pill{transform:translateX(${G.seg.w / 2}px)}
    .tab{position:absolute;top:0;height:${G.seg.h}px;width:${G.seg.w / 2}px;display:flex;gap:5px;align-items:center;justify-content:center;
      font:600 12.5px 'Lensbar Inter',system-ui,sans-serif;color:#C2C2C2;cursor:pointer;transition:color .2s;user-select:none}
    .tab svg{width:13px;height:13px;stroke-width:2.1}
    .tab.r{left:0}.tab.s{left:${G.seg.w / 2}px}
    .seg:not(.shot) .tab.r,.seg.shot .tab.s{color:#13161D}
    .seg:not(.shot) .tab.s:hover,.seg.shot .tab.r:hover{color:#fff}
    .modes{position:absolute;left:${G.modes.x}px;top:${G.modes.y}px;width:${3 * G.modes.w + 2 * G.modes.gap}px;height:${G.modes.h}px;transition:opacity .2s}
    .modes.gone{opacity:0;pointer-events:none}.modes.gone .mode{pointer-events:none}
    .mode{position:absolute;top:0;width:${G.modes.w}px;height:${G.modes.h}px;display:flex;align-items:center;justify-content:center;
      color:#C2C2C2;pointer-events:auto;cursor:pointer;border:0;background:none;transition:color .12s}
    .mode:hover{color:#fff}.mode:active{color:#A6A6A6}
    .mode.na{color:#4A4F58;cursor:default}
    .mode svg{width:21px;height:21px;stroke-width:1.6}
    .mode .dot{position:absolute;width:5.2px;height:5.2px;border-radius:50%;background:#FF4545;left:calc(50% + 7.5px);top:7px}
    .mode.na .dot{display:none}
    .logo{position:absolute;left:50%;top:9px;margin-left:-8px;width:16px;height:16px;color:#EDEDED;opacity:0;pointer-events:none}
    .tip{position:fixed;top:${G.H + 8}px;left:50%;transform:translateX(-50%);background:#0F1116;color:#EDEDED;
      font:500 12px 'Lensbar Tight',system-ui,sans-serif;padding:6px 10px;border-radius:8px;white-space:nowrap;pointer-events:none;
      opacity:0;transition:opacity .12s;box-shadow:0 4px 18px rgba(0,0,0,.25)}
    .tip.show{opacity:1}
    /* area selection */
    .layer{position:fixed;inset:0;cursor:crosshair;pointer-events:auto;z-index:2147483647}
    .layer .dim{position:absolute;inset:0;background:rgba(0,0,0,.38)}
    .layer .box{position:absolute;border:1.5px solid #fff;box-shadow:0 0 0 100000px rgba(0,0,0,.38);display:none}
    .layer.dragging .dim{display:none}.layer.dragging .box{display:block}
    .hint{position:fixed;top:18px;left:50%;transform:translateX(-50%);background:rgba(15,17,22,.94);color:#F2F2F2;
      font:500 13px 'Lensbar Tight',system-ui,sans-serif;padding:8px 14px;border-radius:999px;white-space:nowrap;pointer-events:none}
    .size{position:absolute;background:rgba(15,17,22,.94);color:#fff;font:500 12px 'Lensbar Tight',system-ui,sans-serif;
      padding:4px 9px;border-radius:999px;pointer-events:none;white-space:nowrap}
    /* countdown */
    .count{position:fixed;inset:0;display:grid;place-items:center;pointer-events:none;z-index:2147483647}
    .count div{width:104px;height:104px;border-radius:50%;background:rgba(15,17,22,.92);color:#fff;display:grid;place-items:center;
      font:700 46px 'Lensbar Tight',system-ui,sans-serif;animation:pop .9s ease-out}
    @keyframes pop{0%{transform:scale(.7);opacity:0}25%{transform:scale(1);opacity:1}85%{opacity:1}100%{opacity:.0}}
    /* toast */
    .toast{position:fixed;top:14px;left:50%;transform:translate(-50%,-8px);display:flex;align-items:center;gap:12px;
      background:#0F1116;color:#fff;border-radius:16px;padding:10px 16px 10px 10px;min-width:220px;max-width:min(520px,92vw);
      box-shadow:0 10px 34px rgba(0,0,0,.32);opacity:0;transition:opacity .18s,transform .18s;pointer-events:auto;cursor:default;z-index:2147483647}
    .toast.show{opacity:1;transform:translate(-50%,0)}
    .toast.click{cursor:pointer}
    .toast img{width:64px;height:44px;object-fit:cover;object-position:top;border-radius:7px;background:#20242C;flex:none}
    .toast .ic{width:44px;height:44px;border-radius:10px;background:#1C2028;display:grid;place-items:center;color:#EDEDED;flex:none}
    .toast .t{font:600 13.5px 'Lensbar Inter',system-ui,sans-serif;line-height:1.25}
    .toast .d{font:500 12px 'Lensbar Tight',system-ui,sans-serif;color:#8C8C8C;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    /* the menu card, under the toolbar button */
    .menu{position:fixed;top:8px;right:12px;width:312px;padding:14px 14px 12px;background:#0F1116;color:#fff;border-radius:20px;
      box-shadow:0 18px 50px rgba(0,0,0,.38),0 0 0 1px rgba(255,255,255,.06);pointer-events:auto;z-index:2147483647;
      font:500 13px 'Lensbar Tight',system-ui,-apple-system,'Segoe UI',sans-serif;-webkit-font-smoothing:antialiased;
      transform-origin:top right;opacity:0;transform:translateY(-6px) scale(.97);transition:opacity .16s ease,transform .2s cubic-bezier(.2,.8,.2,1)}
    .menu.show{opacity:1;transform:none}
    :where(.menu) button{font:inherit;color:inherit;margin:0}
    .mhead{display:flex;align-items:center;gap:9px;margin-bottom:12px;color:#EDEDED}
    .mhead b{font:700 15px 'Lensbar Tight',system-ui,sans-serif}
    .menu .mgear{margin-left:auto;width:30px;height:30px;display:grid;place-items:center;border:0;border-radius:10px;background:none;color:#C2C2C2;cursor:pointer}
    .mgear:hover{color:#fff;background:rgba(255,255,255,.05)}
    .mseg{position:relative;display:flex;height:32px;border-radius:16px;background:#323A46;padding:3px}
    .mpill{position:absolute;top:3px;left:3px;width:calc(50% - 3px);height:26px;border-radius:13px;background:#ECECEC;
      transition:transform .22s cubic-bezier(.65,0,.35,1),background-color .22s}
    .mseg.shot .mpill{transform:translateX(100%)}
    .mpill.moving{background:#8C919B}
    .mseg button{position:relative;flex:1;border:0;background:none;display:flex;align-items:center;justify-content:center;gap:6px;
      font:600 13px 'Lensbar Inter',system-ui,sans-serif;color:#C2C2C2;cursor:pointer;transition:color .2s}
    .mseg:not(.shot) .mr,.mseg.shot .ms{color:#13161D}
    .mseg:not(.shot) .ms:hover,.mseg.shot .mr:hover{color:#fff}
    .mmodes{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}
    .mmodes.one{grid-template-columns:1fr}
    .mmodes.one .mtile{display:flex;align-items:center;justify-content:center;gap:10px;font-size:14px;font-weight:600}
    .mmodes.one .mtile .dot{left:auto;right:16px;top:50%;margin-top:-3px}
    .mmodes.gone,.mfoot.gone{display:none}
    .mtile{position:relative;height:62px;border:0;border-radius:14px;background:#1C2028;color:#C2C2C2;cursor:pointer;display:grid;place-items:center;
      transition:background .12s,color .12s}
    .mtile:hover{background:#272C36;color:#fff}.mtile:active{color:#A6A6A6}
    .mtile svg{width:23px;height:23px;stroke-width:1.6}
    .mtile .dot{position:absolute;width:6px;height:6px;border-radius:50%;background:#FF4545;left:calc(50% + 9px);top:15px}
    .mtile.na{color:#474C55;cursor:default;background:#161A21}.mtile.na .dot{display:none}
    .mlabel{margin-top:9px;min-height:17px;text-align:center;color:#8C8C8C;font-size:12.5px}
    .mnote{margin-top:6px;padding:9px 11px;border-radius:11px;background:#1A1E26;color:#B8BBC2;font-size:12px;line-height:1.45}
    .mfoot{display:flex;align-items:center;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid #1C2028}
    .mchip{display:flex;align-items:center;gap:7px;height:32px;padding:0 11px 0 9px;border:0;border-radius:99px;background:#1C2028;color:#E6E6E6;
      cursor:pointer;font:500 12.5px 'Lensbar Tight',system-ui,sans-serif;transition:background .12s,color .12s}
    .mchip:hover{background:#272C36}.mchip.off{color:#696969}.mchip.off:hover{color:#C2C2C2}
    .toast .act{margin-left:8px;width:34px;height:34px;display:grid;place-items:center;border:0;border-radius:50%;padding:0;
      background:transparent;color:#C2C2C2;cursor:pointer;flex:none;transition:background .14s,color .14s}
    .toast .act:hover{background:#FFFFFF;color:#13161D}
    .toast .act svg{width:16px;height:16px}
    /* recording controls card */
    .rtop{display:flex;align-items:center;gap:10px;padding:2px 2px 0}
    .rdot{width:9px;height:9px;border-radius:50%;background:#8A8F99;flex:none;animation:rblink 1s steps(1) infinite}
    @keyframes rblink{50%{opacity:.25}}
    .rtime{font:700 26px 'Lensbar Tight',system-ui,sans-serif;letter-spacing:.3px;font-variant-numeric:tabular-nums}
    .rwhat{margin-left:auto;color:#8C8C8C;font-size:12px}
    .rbar{display:flex;align-items:center;gap:2px;margin-top:12px;background:#1C2028;border-radius:14px;padding:4px 6px}
    .rbtn{width:34px;height:34px;display:grid;place-items:center;border:0;border-radius:10px;background:none;color:#C2C2C2;cursor:pointer;transition:color .12s,background .12s}
    .rbtn:hover{color:#fff;background:rgba(255,255,255,.06)}
    .rbtn.off{color:#696969}.rbtn.on{color:#fff;background:rgba(255,255,255,.1)}
    .rbtn.stop{color:#FF6464}.rbtn.stop:hover{color:#FF4545}
    .rsep{width:1px;height:20px;background:#2C313A;margin:0 6px}
    .rgrow{flex:1}
    .rconfirm{display:none;align-items:center;justify-content:space-between;gap:8px;margin-top:10px;color:#B8BBC2;font-size:12.5px}
    .rconfirm.show{display:flex}
    .rpill{height:30px;padding:0 13px;border:0;border-radius:99px;background:#1C2028;color:#fff;cursor:pointer;font:500 12.5px 'Lensbar Tight',system-ui,sans-serif}
    .rpill.primary{background:#F2F2F2;color:#13161D;font-weight:700}
    .rhint{margin-top:8px;text-align:center;color:#6F737B;font-size:11.5px}
    /* recording frame */
    .frame{position:fixed;border:2px solid rgba(255,69,69,.92);border-radius:3px;pointer-events:none;z-index:2147483646}
  </style>
  <div class="wrap hidden">
    <svg class="shape" width="${G.W}" height="${G.H}"><path d=""/></svg>
    <div class="content">
      <button class="btn" data-id="tabAudio" data-tip="Tab sound" style="left:${G.sys.x}px;top:${G.sys.y}px"></button>
      <button class="btn" data-id="mic" data-tip="Microphone" style="left:${G.mic.x}px;top:${G.mic.y}px"></button>
      <button class="btn" data-id="pin" data-tip="Pin: keep the bar on this page" style="left:${G.pin.x}px;top:${G.pin.y}px"></button>
      <div class="seg">
        <div class="pill"></div>
        <div class="tab r" data-id="tab-rec">${svg('record', 13)}Record</div>
        <div class="tab s" data-id="tab-shot">${svg('camera', 13)}Screenshot</div>
      </div>
      <button class="btn" data-id="more" data-tip="Settings" style="left:${G.more.x}px;top:${G.more.y}px">${svg('gear', 15)}</button>
      <button class="btn" data-id="close" data-tip="Close (Esc)" style="left:${G.close.x}px;top:${G.close.y}px">${svg('close', 14)}</button>
      <div class="modes rec"></div>
      <div class="modes shot"></div>
    </div>
    <div class="logo">${LOGO}</div>
  </div>
  <div class="tip"></div>`);

  const $ = s => root.querySelector(s);
  const wrap = $('.wrap'), path = $('svg.shape path'), content = $('.content'), logo = $('.logo'), tip = $('.tip');
  const seg = $('.seg'), pill = $('.pill');
  const btn = id => root.querySelector(`.btn[data-id="${id}"]`);

  for (const kind of ['rec', 'shot']) {
    const box = $(`.modes.${kind}`);
    MODES[kind].forEach((m, i) => {
      const b = document.createElement('button');
      b.className = 'mode';
      b.dataset.id = `${kind}:${m.id}`;
      b.dataset.tip = m.tip;
      b.style.left = `${i * (G.modes.w + G.modes.gap)}px`;
      setHTML(b, svg(m.icon, 21) + (kind === 'rec' ? '<span class="dot"></span>' : ''));
      box.appendChild(b);
    });
  }

  function mount() { if (!host.isConnected) document.documentElement.appendChild(host); }

  function renderButtons() {
    const a = btn('tabAudio'), m = btn('mic'), p = btn('pin');
    setHTML(a, svg(S.tabAudio ? 'speaker' : 'speakerOff', 15));
    a.classList.toggle('off', !S.tabAudio);
    a.dataset.tip = S.tabAudio ? 'Tab sound: on' : 'Tab sound: off';
    setHTML(m, svg(S.mic ? 'mic' : 'micOff', 15));
    m.classList.toggle('off', !S.mic);
    m.dataset.tip = S.mic ? 'Microphone: on' : 'Microphone: off';
    setHTML(p, svg(S.pinned ? 'pinOn' : 'pin', 15));
    p.classList.toggle('on', S.pinned);
    p.dataset.tip = S.pinned ? 'Pinned: stays on this page (click to unpin)' : 'Pin: keep the bar on this page';
    const shot = S.lastTab !== 'rec';
    seg.classList.toggle('shot', shot);
    $('.modes.rec').classList.toggle('gone', shot);
    $('.modes.shot').classList.toggle('gone', !shot);
    root.querySelectorAll('.modes.rec .mode').forEach(b => {
      const na = !canTabCapture && !canCropRecord && !b.dataset.id.endsWith(':screen');
      b.classList.toggle('na', na);
      if (na) b.dataset.tip = 'Not available in this browser: use "Record a screen or window"';
    });
  }

  // ------------------------------------------------------------------ open / close / tuck animation

  let dock = 1, dockFrom = 1, dockTo = 1, dockStart = 0, dockMs = 300;
  let showLogo = false, open = false, closing = false, raf = 0, onClosed = null;
  let lastOver = 0, pressedInside = false;

  function setPath(d) {
    const e = d < 0.5 ? 4 * d * d * d : 1 - Math.pow(-2 * d + 2, 3) / 2;
    const T = G.tab;
    const along = G.W + (T.along - G.W) * e;
    const depth = G.H + (T.depth - G.H) * e;
    const ew = G.ear + (T.earAlong - G.ear) * e;
    const eh = G.ear + (T.earDepth - G.ear) * e;
    let r = G.radius + (T.radius - G.radius) * e;
    r = Math.max(1, Math.min(r, depth - 1, (along - 2 * ew) / 2 - 1));
    path.setAttribute('d', notchPath(along, depth, ew, eh, r, (G.W - along) / 2));
    const shapeA = showLogo ? 1 : Math.max(0, Math.min(1, (1 - d) / 0.25));
    path.style.opacity = shapeA;
    const contentA = Math.max(0, 1 - d / 0.45) * shapeA;
    content.style.opacity = contentA;
    content.classList.toggle('off', d > 0.05);
    logo.style.opacity = showLogo ? Math.max(0, (d - 0.6) / 0.4) : 0;
    path.style.pointerEvents = shapeA > 0.05 ? 'auto' : 'none';
  }

  function animate(to, ms) {
    dockFrom = dock; dockTo = to; dockStart = performance.now();
    dockMs = Math.max(60, ms * Math.max(0.15, Math.abs(to - dock)));
    if (to > 0.5) hideTip();
    if (!raf) raf = requestAnimationFrame(step);
  }

  function step(now) {
    raf = 0;
    const t = Math.min(1, (now - dockStart) / dockMs);
    dock = dockFrom + (dockTo - dockFrom) * t;
    setPath(dock);
    if (t < 1) { raf = requestAnimationFrame(step); return; }
    if (closing && dock >= 1) {
      closing = false;
      wrap.classList.add('hidden');
      open = false;
      const f = onClosed; onClosed = null;
      f && f();
    }
  }

  async function show({ tucked = false } = {}) {
    S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
    mount();
    if (toastEl && !tucked) { toastEl.remove(); toastEl = null; }
    renderButtons();
    wrap.classList.remove('hidden');
    open = true;
    closing = false;
    if (tucked && S.pinned) {
      showLogo = true; dock = 1; setPath(1);
    } else {
      showLogo = false; dock = 1; setPath(1);
      lastOver = performance.now() + 1200;
      animate(0, 300);
    }
    startWatch();
  }

  function close(then) {
    if (!open) { then && then(); return; }
    stopWatch();
    showLogo = false;
    closing = true;
    onClosed = then || null;
    animate(1, 170);
  }

  /** Hide instantly (before a capture). */
  function closeNow() {
    stopWatch();
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    closing = false;
    open = false;
    dock = 1;
    wrap.classList.add('hidden');
    hideTip();
  }

  // pinned: tuck into a small tab after the mouse has been away, open again on hover
  let watchTimer = 0, mouse = { x: -1, y: -1 };
  const onMove = e => { mouse.x = e.clientX; mouse.y = e.clientY; };
  function startWatch() {
    stopWatch();
    document.addEventListener('mousemove', onMove, { capture: true, passive: true });
    watchTimer = setInterval(watch, 80);
  }
  function stopWatch() {
    clearInterval(watchTimer);
    watchTimer = 0;
    document.removeEventListener('mousemove', onMove, { capture: true });
  }
  function overBar() {
    const left = innerWidth / 2 - G.W / 2;
    if (dockTo > 0.5) {
      const body = G.tab.along - 2 * G.tab.earAlong;
      return mouse.y >= 0 && mouse.y <= G.tab.depth + 6 && Math.abs(mouse.x - innerWidth / 2) <= body / 2 + 6;
    }
    return mouse.y >= 0 && mouse.y <= G.H + 4 && mouse.x >= left - 4 && mouse.x <= left + G.W + 4;
  }
  function watch() {
    if (!open || closing) return;
    const now = performance.now();
    const over = overBar();
    if (!S.pinned) {
      if (dockTo > 0.5 && showLogo) animate(0, 320);
      return;
    }
    if (over || pressedInside) {
      if (now > lastOver) lastOver = now;
      if (dockTo > 0.5) { showLogo = true; animate(0, 320); }
    } else if (dockTo < 0.5 && now - lastOver > 1600) {
      showLogo = true;
      animate(1, 750);
    }
  }

  // ------------------------------------------------------------------ tooltips + clicks

  let tipFor = null;
  function hideTip() { tip.classList.remove('show'); tipFor = null; }
  root.addEventListener('mouseover', e => {
    const el = e.target.closest && e.target.closest('[data-tip]');
    if (!el || dock > 0.05) { if (!el) hideTip(); return; }
    if (tipFor === el) return;
    tipFor = el;
    tip.textContent = el.dataset.tip;
    const r = el.getBoundingClientRect();
    tip.style.left = `${r.left + r.width / 2}px`;
    tip.classList.add('show');
  });
  root.addEventListener('mouseout', e => {
    if (!e.relatedTarget || !root.contains(e.relatedTarget)) hideTip();
  });
  root.addEventListener('pointerdown', () => { pressedInside = true; });
  window.addEventListener('pointerup', () => { pressedInside = false; }, true);

  root.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('[data-id]');
    if (!el || dock > 0.05 || !open) return;
    e.stopPropagation();
    press(el.dataset.id);
  });

  async function save(patch) {
    Object.assign(S, patch);
    await api.storage.local.set(patch);
    renderButtons();
  }

  async function press(id) {
    switch (id) {
      case 'tab-rec':
      case 'tab-shot': {
        const t = id === 'tab-rec' ? 'rec' : 'shot';
        if (S.lastTab === t) return;
        pill.classList.add('moving');
        setTimeout(() => pill.classList.remove('moving'), 220);
        await save({ lastTab: t });
        return;
      }
      case 'tabAudio': return save({ tabAudio: !S.tabAudio });
      case 'mic': {
        await save({ mic: !S.mic });
        if (S.mic) {
          const r = await send({ type: 'mic-check' });
          if (r && r.granted === false) send({ type: 'ask-mic' });
        }
        return;
      }
      case 'pin': return save({ pinned: !S.pinned });
      case 'more': close(); send({ type: 'open-options' }); return;
      case 'close': close(); return;
    }
    const [kind, mode] = id.split(':');
    if (kind === 'rec' && !canTabCapture && !canCropRecord && mode !== 'screen') return;
    if (kind === 'shot') return screenshot(mode);
    if (kind === 'rec') return record(mode);
  }

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && open && dock < 0.5 && !selecting) { close(); }
  }, true);

  // ------------------------------------------------------------------ toasts

  let toastEl = null, toastTimer = 0;
  function toast(title, detail = '', { img = null, onClick = null, ms = 4000, icon = 'logo', onDelete = null } = {}) {
    mount();
    if (toastEl) toastEl.remove();
    clearTimeout(toastTimer);
    const t = document.createElement('div');
    t.className = 'toast' + (onClick ? ' click' : '');
    const lead = img ? `<img alt="">` : `<div class="ic">${icon === 'logo' ? LOGO : svg(icon, 18)}</div>`;
    setHTML(t, `${lead}<div style="min-width:0"><div class="t"></div><div class="d"></div></div>`);
    t.querySelector('.t').textContent = title;
    t.querySelector('.d').textContent = detail;
    if (!detail) t.querySelector('.d').remove();
    if (img) t.querySelector('img').src = img;
    if (onDelete) {
      const del = document.createElement('button');
      del.className = 'act';
      del.title = 'Delete this file';
      setHTML(del, svg('trash', 16));
      del.addEventListener('click', async e => {
        e.stopPropagation();
        del.disabled = true;
        await onDelete();
        clearTimeout(toastTimer);
        t.querySelector('.t').textContent = 'Deleted';
        const d = t.querySelector('.d');
        if (d) d.textContent = 'Removed from Downloads';
        del.remove();
        t.classList.remove('click');
        toastTimer = setTimeout(dismiss, 1600);
      });
      t.appendChild(del);
    }
    if (onClick) t.addEventListener('click', () => { onClick(); dismiss(); });
    root.appendChild(t);
    toastEl = t;
    requestAnimationFrame(() => t.classList.add('show'));
    const dismiss = () => {
      t.classList.remove('show');
      setTimeout(() => { t.remove(); if (toastEl === t) toastEl = null; }, 220);
    };
    toastTimer = setTimeout(dismiss, ms);
    t.addEventListener('mouseenter', () => clearTimeout(toastTimer));
    t.addEventListener('mouseleave', () => { toastTimer = setTimeout(dismiss, 2500); });
  }

  // ------------------------------------------------------------------ area selection

  let selecting = false;
  /**
   * Drag to select an area. Dragging to the top or bottom edge (or using the wheel) scrolls the page,
   * so an area can be longer than the screen. Returns { x, y, w, h } in the window as it is now, plus
   * docY (the top in the scrolled page) and sc (the scroller) so a long area can be scrolled and stitched.
   * maxH: the tallest area allowed (recordings: the visible height, since a video shows one screen).
   */
  function selectArea(hintText, { maxH = Infinity } = {}) {
    return new Promise(resolve => {
      selecting = true;
      mount();
      const sc = findScroller();
      const off = () => sc.get() - (sc.win ? 0 : sc.rect.y);      // window y -> y in the scrolled page
      const layer = document.createElement('div');
      layer.className = 'layer';
      setHTML(layer, '<div class="dim"></div><div class="box"></div><div class="size"></div><div class="hint"></div>');
      layer.querySelector('.hint').textContent = hintText;
      const box = layer.querySelector('.box'), size = layer.querySelector('.size');
      size.style.display = 'none';
      root.appendChild(layer);
      let start = null, last = null, rect = null, raf = 0;
      const done = r => {
        selecting = false;
        cancelAnimationFrame(raf);
        layer.remove();
        window.removeEventListener('keydown', key, true);
        window.removeEventListener('scroll', update, true);
        resolve(r);
      };
      const key = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(null); } };
      window.addEventListener('keydown', key, true);
      layer.addEventListener('contextmenu', e => { e.preventDefault(); done(null); });

      // the area in page coordinates (y counted down the scrolled page), drawn where it sits in the window now
      function update() {
        if (!start || !last) return;
        const o = off();
        const x = Math.max(0, Math.min(start.x, last.x)), x2 = Math.min(innerWidth, Math.max(start.x, last.x));
        let y = Math.min(start.y, last.y + o), y2 = Math.max(start.y, last.y + o);
        y = Math.max(-(sc.win ? 0 : sc.rect.y), y);
        if (y2 - y > maxH) { if (last.y + o < start.y) y = y2 - maxH; else y2 = y + maxH; }
        const w = x2 - x, h = y2 - y;
        if (w < 3 && h < 3) return;
        rect = { x, y, w, h };
        layer.classList.add('dragging');
        const top = y - o;
        // draw only the part on screen (a box thousands of pixels tall loses its dimmed surroundings)
        const vTop = Math.max(-3, top), vBottom = Math.min(innerHeight + 3, top + h);
        Object.assign(box.style, { left: `${x}px`, top: `${vTop}px`, width: `${w}px`, height: `${Math.max(0, vBottom - vTop)}px` });
        const k = devicePixelRatio || 1;
        size.textContent = `${Math.round(w * k)} × ${Math.round(h * k)}`;
        size.style.display = '';
        const bottom = top + h;
        const below = bottom + 34 < innerHeight;
        Object.assign(size.style, {
          left: `${Math.min(x, innerWidth - 120)}px`,
          top: `${below ? Math.max(8, bottom + 8) : Math.max(8, Math.min(innerHeight - 34, top - 30))}px`,
        });
      }
      // near the top or bottom edge: scroll, faster the further in
      function edgeScroll() {
        raf = requestAnimationFrame(edgeScroll);
        if (!start || !last) return;
        const zone = 48;
        let v = 0;
        if (last.y > innerHeight - zone) v = Math.ceil((last.y - (innerHeight - zone)) / zone * 24);
        else if (last.y < zone) v = -Math.ceil((zone - last.y) / zone * 24);
        if (!v) return;
        const before = sc.get();
        sc.set(before + v);
        if (sc.get() !== before) update();
      }
      window.addEventListener('scroll', update, true);        // the wheel works while dragging too

      layer.addEventListener('pointerdown', e => {
        if (e.button !== 0) return;
        start = { x: e.clientX, y: e.clientY + off() };
        last = { x: e.clientX, y: e.clientY };
        layer.setPointerCapture(e.pointerId);
        raf = requestAnimationFrame(edgeScroll);
      });
      layer.addEventListener('pointermove', e => {
        if (!start) return;
        last = { x: e.clientX, y: Math.max(0, Math.min(innerHeight, e.clientY)) };
        update();
      });
      layer.addEventListener('wheel', e => { sc.set(sc.get() + e.deltaY); update(); }, { passive: true });
      layer.addEventListener('pointerup', () => {
        if (!start) return;
        start = null;
        cancelAnimationFrame(raf);
        if (rect && rect.w >= 8 && rect.h >= 8) {
          // bring an area that fits on screen fully into view
          let top = rect.y - off();
          const viewH = sc.win ? innerHeight : sc.rect.h, viewTop = sc.win ? 0 : sc.rect.y;
          if (rect.h <= viewH && (top < viewTop || top + rect.h > viewTop + viewH)) {
            sc.set(sc.get() + (top < viewTop ? top - viewTop : top + rect.h - (viewTop + viewH)));
            top = rect.y - off();
          }
          done({ x: rect.x, y: top, w: rect.w, h: rect.h, docY: rect.y + (sc.win ? 0 : sc.rect.y), sc });
        } else { rect = null; layer.classList.remove('dragging'); size.style.display = 'none'; }
      });
    });
  }

  async function countdown() {
    if (!S.countdown) return;
    mount();
    const c = document.createElement('div');
    c.className = 'count';
    root.appendChild(c);
    for (const n of [3, 2, 1]) {
      setHTML(c, `<div>${n}</div>`);
      await sleep(900);
    }
    c.remove();
    await frame2();
    await sleep(80);
  }

  // ------------------------------------------------------------------ screenshots

  function stamp() {
    const d = new Date(), p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
  }

  function dataUrlToBlob(dataUrl) {
    const [head, b64] = dataUrl.split(',');
    const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/png';
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return new Blob([u8], { type: mime });
  }
  const toBitmap = dataUrl => createImageBitmap(dataUrlToBlob(dataUrl));
  const canvasBlob = (cv, type, q) => new Promise(r => cv.toBlob(r, type, q));

  async function hideUiForCapture() {
    const wasOpen = open;
    closeNow();
    if (toastEl) { toastEl.remove(); toastEl = null; }
    host.style.visibility = 'hidden';
    await frame2();
    await sleep(60);
    return wasOpen;
  }
  function restoreUi() { host.style.visibility = ''; }

  async function captureVisible() {
    const r = await send({ type: 'capture' });
    if (!r || !r.ok) throw new Error((r && r.error) || 'Capture failed');
    return toBitmap(r.dataUrl);
  }

  async function screenshot(mode) {
    let area = null;
    if (mode === 'area') {
      closeNow();
      area = await selectArea('Drag to select  ·  Drag to an edge to keep going  ·  Esc to cancel');
      if (!area) { afterCapture(); return; }
    }
    await hideUiForCapture();
    let canvas;
    try {
      if (mode === 'full') canvas = await fullPage();
      else if (area && (area.y < 0 || area.y + area.h > innerHeight + 1)) canvas = await longArea(area);
      else {
        const bmp = await captureVisible();
        const k = bmp.width / innerWidth;
        const r = area || { x: 0, y: 0, w: innerWidth, h: innerHeight };
        canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(r.w * k));
        canvas.height = Math.max(1, Math.round(r.h * k));
        canvas.getContext('2d').drawImage(bmp, Math.round(r.x * k), Math.round(r.y * k), canvas.width, canvas.height, 0, 0, canvas.width, canvas.height);
      }
    } catch (e) {
      restoreUi();
      toast('Screenshot failed', String(e && e.message || e), { icon: 'close', ms: 5000 });
      afterCapture();
      return;
    }
    restoreUi();
    await saveImage(canvas);
    afterCapture();
  }

  async function saveImage(canvas) {
    const jpg = S.imageFormat === 'jpg';
    const type = jpg ? 'image/jpeg' : 'image/png';
    const blob = await canvasBlob(canvas, type, 0.92);
    const ext = jpg ? 'jpg' : 'png';
    const name = `Screenshot_${stamp()}.${ext}`;
    const url = URL.createObjectURL(blob);
    const folder = cleanFolder(S.shotFolder);
    // Firefox can't download a link made inside a web page, so the file itself goes to Lensbar's background
    const ff = /firefox/i.test(navigator.userAgent);
    let res = await send({ type: 'save', url, blob: ff ? blob : undefined, filename: folder ? `${folder}/${name}` : name });
    if (!res || !res.ok) {
      const a = document.createElement('a');
      a.href = url; a.download = name;
      document.documentElement.appendChild(a); a.click(); a.remove();
      res = { ok: true, id: null };
    }
    setTimeout(() => URL.revokeObjectURL(url), 120000);
    let copied = false;
    if (S.copyShots) {
      try {
        const png = jpg ? await canvasBlob(canvas, 'image/png') : blob;
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })]);
        copied = true;
      } catch {}
    }
    const thumb = document.createElement('canvas');
    const tw = 128, th = Math.max(1, Math.round(Math.min(canvas.height, canvas.width * 0.7) * tw / canvas.width));
    thumb.width = tw; thumb.height = th;
    thumb.getContext('2d').drawImage(canvas, 0, 0, canvas.width, th * canvas.width / tw, 0, 0, tw, th);
    const id = res.id;
    toast(copied ? 'Screenshot saved and copied' : 'Screenshot saved',
          `${canvas.width} × ${canvas.height}  ·  ${S.saveAs ? 'Saved where you chose' : 'Downloads' + (folder ? '/' + folder : '')}`,
          {
            img: thumb.toDataURL('image/png'), ms: 8000,
            onClick: id != null ? () => send({ type: 'show-download', id }) : null,
            onDelete: id != null ? async () => {
              await send({ type: 'delete-download', id });
              if (copied) { try { await navigator.clipboard.writeText(''); } catch {} }
            } : null,
          });
  }

  /// An area longer than the screen: scroll through it and stitch the pieces (same idea as the full page).
  async function longArea(area) {
    const sc = area.sc;
    const viewTop = sc.win ? 0 : sc.rect.y, viewH = sc.win ? innerHeight : sc.rect.h;
    const y0 = area.docY - viewTop;                // top of the area in the scroller's content
    const total = Math.min(area.h, 25000);
    const start = sc.get();
    const docEl = document.documentElement;
    const prevBehavior = docEl.style.scrollBehavior;
    docEl.style.scrollBehavior = 'auto';
    let canvas = null, ctx = null, k = 1, scale = 1, done = 0, restoreFixed = null;
    try {
      for (let i = 0; done < total && i < 400; i++) {
        sc.set(y0 + done);
        await frame2();
        await sleep(i === 0 ? 120 : 180);
        if (i === 1 && sc.win) { restoreFixed = hideFixed(); await frame2(); }
        send({ type: 'badge', text: `${Math.round((done / total) * 100)}%` });
        const bmp = await captureVisible();
        if (!canvas) {
          k = bmp.width / innerWidth;
          scale = Math.min(1, 32000 / (total * k), Math.sqrt(250e6 / (area.w * k * total * k)));
          canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(area.w * k * scale));
          canvas.height = Math.max(1, Math.round(total * k * scale));
          ctx = canvas.getContext('2d');
        }
        const actual = sc.get();                                     // the page may not scroll all the way
        const from = y0 + done;                                      // next part needed, in content y
        const top = from - actual + viewTop;                         // ...where it shows in the window
        const sh = Math.min(total - done, viewTop + viewH - top);
        if (sh <= 0 || top < 0) break;
        ctx.drawImage(bmp, Math.round(area.x * k), Math.round(top * k), Math.round(area.w * k), Math.round(sh * k),
                      0, Math.round(done * k * scale), canvas.width, Math.round(sh * k * scale));
        done += sh;
      }
    } finally {
      restoreFixed && restoreFixed();
      sc.set(start);
      docEl.style.scrollBehavior = prevBehavior;
      send({ type: 'badge', text: '' });
    }
    if (!canvas) throw new Error('Nothing to capture.');
    return canvas;
  }

  // ---- full page: scroll + stitch (Firefox can grab the whole page in one go)

  function findScroller() {
    const se = document.scrollingElement || document.documentElement;
    const vw = document.documentElement.clientWidth || innerWidth;
    const vh = document.documentElement.clientHeight || innerHeight;
    if (se.scrollHeight > vh + 4) {
      return {
        win: true, rect: { x: 0, y: 0, w: vw, h: vh }, height: se.scrollHeight,
        get: () => window.scrollY, set: y => window.scrollTo({ top: y, left: window.scrollX, behavior: 'instant' }),
      };
    }
    let best = null, bestArea = 0;
    for (const el of document.querySelectorAll('body *')) {
      if (el.scrollHeight <= el.clientHeight + 40 || el.clientHeight < 120) continue;
      const oy = getComputedStyle(el).overflowY;
      if (!/(auto|scroll|overlay)/.test(oy)) continue;
      const r = el.getBoundingClientRect();
      const a = Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
      if (a > bestArea) { best = el; bestArea = a; }
    }
    if (best) {
      const r = best.getBoundingClientRect();
      return {
        win: false, rect: { x: r.left + best.clientLeft, y: r.top + best.clientTop, w: best.clientWidth, h: best.clientHeight },
        height: best.scrollHeight, get: () => best.scrollTop, set: y => { best.scrollTop = y; },
      };
    }
    return { win: true, rect: { x: 0, y: 0, w: vw, h: vh }, height: vh, get: () => window.scrollY, set: () => {} };
  }

  function hideFixed() {
    const hidden = [];
    for (const el of document.querySelectorAll('body *')) {
      const p = getComputedStyle(el).position;
      if (p === 'fixed' || p === 'sticky') {
        hidden.push([el, el.style.getPropertyValue('visibility'), el.style.getPropertyPriority('visibility')]);
        el.style.setProperty('visibility', 'hidden', 'important');
      }
    }
    return () => hidden.forEach(([el, v, p]) => v ? el.style.setProperty('visibility', v, p) : el.style.removeProperty('visibility'));
  }

  async function fullPage() {
    const sc = findScroller();
    const MAX_H = 25000;                       // CSS px; very long or endless pages are cut here
    const total = Math.min(sc.height, MAX_H);
    const start = sc.get();
    const docEl = document.documentElement;
    const prevBehavior = docEl.style.scrollBehavior;
    docEl.style.scrollBehavior = 'auto';

    // Every browser scrolls and stitches: a one-shot picture of the whole document (Firefox can take one) misses
    // what pages only draw once scrolled to (lazy images, sections that load or animate in), leaving gaps.
    const step = sc.rect.h;
    const positions = [];
    for (let y = 0; y < total; y += step) positions.push(Math.min(y, Math.max(0, total - step)));
    const uniq = [...new Set(positions)];
    let canvas = null, ctx = null, k = 1, scale = 1, restoreFixed = null;
    try {
      for (let i = 0; i < uniq.length; i++) {
        sc.set(uniq[i]);
        await frame2();
        await sleep(i === 0 ? 120 : 180);
        if (i === 1 && sc.win) { restoreFixed = hideFixed(); await frame2(); }
        send({ type: 'badge', text: `${Math.round((i / uniq.length) * 100)}%` });
        const bmp = await captureVisible();
        if (!canvas) {
          k = bmp.width / innerWidth;
          scale = Math.min(1, 32000 / (total * k), Math.sqrt(250e6 / (sc.rect.w * k * total * k)));
          canvas = document.createElement('canvas');
          canvas.width = Math.round(sc.rect.w * k * scale);
          canvas.height = Math.round(total * k * scale);
          ctx = canvas.getContext('2d');
        }
        const actual = sc.get();
        const sh = Math.min(sc.rect.h, total - actual);
        if (sh <= 0) continue;
        ctx.drawImage(bmp, sc.rect.x * k, sc.rect.y * k, sc.rect.w * k, sh * k,
                      0, Math.round(actual * k * scale), canvas.width, Math.round(sh * k * scale));
      }
    } finally {
      restoreFixed && restoreFixed();
      sc.set(start);
      docEl.style.scrollBehavior = prevBehavior;
      send({ type: 'badge', text: '' });
    }
    if (!canvas) throw new Error('Nothing to capture.');
    return canvas;
  }

  // ------------------------------------------------------------------ recording

  let frameEl = null;
  async function record(mode) {
    if (mode === 'screen' && canCropRecord) return recordInPage();
    if (mode === 'screen') {
      close();
      const r = await send({ type: 'rec-screen' });
      if (!r || !r.ok) toast('Couldn\'t start recording', (r && r.error) || '', { icon: 'close' });
      return;
    }
    if (!canTabCapture) return recordByWindow(mode);
    let area = null;
    if (mode === 'area') {
      closeNow();
      area = await selectArea('Drag the area to record  ·  Drag to an edge to scroll  ·  Esc to cancel', { maxH: innerHeight });
      if (!area) { afterCapture(); return; }
      area = { x: area.x, y: area.y, w: area.w, h: area.h };   // just the box: it goes to the recorder
    } else {
      closeNow();
    }
    if (toastEl) { toastEl.remove(); toastEl = null; }
    await countdown();
    const r = await send({
      type: 'rec-start', area,
      viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio || 1 },
    });
    if (!r || !r.ok) {
      toast('Couldn\'t start recording', (r && r.error) || '', { icon: 'close', ms: 6000 });
      afterCapture();
      return;
    }
    if (area) {
      mount();
      frameEl = document.createElement('div');
      frameEl.className = 'frame';
      Object.assign(frameEl.style, { left: `${area.x - 3}px`, top: `${area.y - 3}px`, width: `${area.w + 6}px`, height: `${area.h + 6}px` });
      root.appendChild(frameEl);
    }
  }

  /// Firefox: "this tab" / "an area" = the Firefox window recorded, then cropped to the page (or the area).
  async function recordByWindow(mode) {
    let area = null;
    if (mode === 'area') {
      closeNow();
      area = await selectArea('Drag the area to record  ·  Drag to an edge to scroll  ·  Esc to cancel', { maxH: innerHeight });
      if (!area) { afterCapture(); return; }
      area = { x: area.x, y: area.y, w: area.w, h: area.h };   // just the box: it goes to the recorder
    } else {
      close();
    }
    const crop = {
      mode, area,
      vp: { x: window.mozInnerScreenX, y: window.mozInnerScreenY, w: innerWidth, h: innerHeight },
      win: { x: screenX, y: screenY, w: outerWidth, h: outerHeight },
      scr: { x: screen.left || 0, y: screen.top || 0, w: screen.width, h: screen.height },
      dpr: devicePixelRatio || 1,
    };
    const r = await send({ type: 'rec-screen', crop });
    if (!r || !r.ok) { toast('Couldn\'t start recording', (r && r.error) || '', { icon: 'close' }); afterCapture(); return; }
    if (area) {
      mount();
      frameEl = document.createElement('div');
      frameEl.className = 'frame';
      Object.assign(frameEl.style, { left: `${area.x - 3}px`, top: `${area.y - 3}px`, width: `${area.w + 6}px`, height: `${area.h + 6}px` });
      root.appendChild(frameEl);
    }
  }

  /**
   * Firefox: Firefox's own "Allow … to see your screen?" box opens right here (pick a window or a screen),
   * then 3, 2, 1, then recording. The recording lives in this page; stopping hands the video to Lensbar's
   * background, which makes an MP4 and saves it. Leaving or reloading the page ends the recording.
   */
  let pageRec = null;
  async function recordInPage() {
    closeNow();
    if (pageRec) return;
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: S.fps }, audio: false });
    } catch (e) {
      if (!(e && e.name === 'NotAllowedError')) toast('Couldn\'t start recording', String(e && e.message || e), { icon: 'close', ms: 6000 });
      afterCapture();
      return;
    }
    await countdown();
    if (!stream.active) { afterCapture(); return; }                 // sharing stopped during 3, 2, 1
    pageRec = new LensRecorder();
    pageRec.onEnded = () => finishPageRec(false);                  // Firefox's own "Stop sharing"
    let r;
    try {
      r = await pageRec.start(stream, { tabAudio: false, mic: S.mic, monitor: false, fps: S.fps, quality: S.quality, soundQuality: S.soundQuality });
    } catch (e) {
      stream.getTracks().forEach(t => t.stop());
      pageRec = null;
      toast('Couldn\'t start recording', String(e && e.message || e), { icon: 'close', ms: 6000 });
      return;
    }
    await send({ type: 'page-rec-started', mic: pageRec.mic, micBlocked: r.micBlocked });
    addEventListener('pagehide', () => finishPageRec(false), { once: true });
  }

  let pageRecBusy = false;
  async function finishPageRec(discard) {
    if (!pageRec || pageRecBusy) return;
    pageRecBusy = true;
    const rec = pageRec;
    try {
      const r = await rec.stop(discard);
      if (r.discarded) { await send({ type: 'page-rec-done', discarded: true }); return; }
      toast('Saving the recording…', 'Making an MP4', { icon: 'record', ms: 600000 });
      await send({ type: 'page-rec-done', blob: rec.blob });
    } catch (e) {
      send({ type: 'page-rec-done', discarded: true, error: String(e && e.message || e) });
    } finally {
      rec.release();
      pageRec = null;
      pageRecBusy = false;
    }
  }

  function afterCapture() {}

  // ------------------------------------------------------------------ the menu card

  const MENU = {
    rec: [
      { id: 'tab', icon: 'tab', label: 'Record this tab (just the website)' },
      { id: 'area', icon: 'area', label: 'Record an area of the page' },
      { id: 'screen', icon: 'browser', label: 'Record the whole browser window' },
    ],
    shot: [
      { id: 'visible', icon: 'visible', label: 'Screenshot the visible part' },
      { id: 'area', icon: 'area', label: 'Screenshot an area' },
      { id: 'full', icon: 'fullpage', label: 'Full page, top to bottom' },
    ],
  };
  // Firefox has no tab recording: one option, which opens Firefox's own "see your screen" box right on this page
  if (canCropRecord) MENU.rec = [{ id: 'screen', icon: 'screen', label: 'Record a screen or window' }];
  let menuEl = null;

  function menuAvailable(kind, id) { return !(kind === 'rec' && !canTabCapture && !canCropRecord && id !== 'screen'); }

  function renderMenu() {
    if (!menuEl) return;
    const shot = S.lastTab !== 'rec';
    menuEl.querySelector('.mseg').classList.toggle('shot', shot);
    menuEl.querySelector('.mmodes.rec').classList.toggle('gone', shot);
    menuEl.querySelector('.mmodes.shot').classList.toggle('gone', !shot);
    menuEl.querySelector('.mfoot').classList.toggle('gone', shot);     // sound / mic only matter for recording
    for (const b of menuEl.querySelectorAll('.mmodes.rec .mtile')) b.classList.toggle('na', !menuAvailable('rec', b.dataset.id));
    const a = menuEl.querySelector('[data-act="tabAudio"]'), m = menuEl.querySelector('[data-act="mic"]');
    a.style.display = canCropRecord ? 'none' : '';                 // Firefox can't share a website's sound
    setHTML(a, svg(S.tabAudio ? 'speaker' : 'speakerOff', 15) + '<span>Tab sound</span>');
    a.classList.toggle('off', !S.tabAudio);
    setHTML(m, svg(S.mic ? 'mic' : 'micOff', 15) + '<span>Mic</span>');
    m.classList.toggle('off', !S.mic);
    const note = menuEl.querySelector('.mnote');
    note.textContent = !canTabCapture && !canCropRecord && !shot ? 'This browser can\'t record a single tab. Use "Record the whole browser window".' : '';
    note.style.display = note.textContent ? '' : 'none';
  }

  async function openMenu() {
    if (menuEl) { closeMenu(); return; }
    S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
    mount();
    if (toastEl) { toastEl.remove(); toastEl = null; }
    const el = document.createElement('div');
    el.className = 'menu';
    let tiles = '';
    for (const kind of ['rec', 'shot']) {
      const one = MENU[kind].length === 1;                          // Firefox's single "record" option: a wide tile
      tiles += `<div class="mmodes ${kind}${one ? ' one' : ''}">` + MENU[kind].map(x =>
        `<button class="mtile" data-act="${kind}:${x.id}" data-id="${x.id}">${svg(x.icon, 23)}${one ? `<span>${x.label}</span>` : ''}${kind === 'rec' ? '<span class="dot"></span>' : ''}</button>`).join('') + '</div>';
    }
    setHTML(el, `
      <div class="mhead">${LOGO}<b>Lensbar</b><button class="mgear" data-act="gear" title="Settings">${svg('gear', 16)}</button></div>
      <div class="mseg"><div class="mpill"></div>
        <button class="mr" data-act="tab-rec">${svg('record', 14)}Record</button>
        <button class="ms" data-act="tab-shot">${svg('camera', 14)}Screenshot</button></div>
      ${tiles}
      <div class="mlabel"></div>
      <div class="mnote"></div>
      <div class="mfoot"><button class="mchip" data-act="tabAudio"></button><button class="mchip" data-act="mic"></button></div>`);
    root.appendChild(el);
    menuEl = el;
    renderMenu();
    for (const b of el.querySelectorAll('.mtile')) {
      const [kind, id] = b.dataset.act.split(':');
      const info = MENU[kind].find(x => x.id === id);
      b.addEventListener('mouseenter', () => { el.querySelector('.mlabel').textContent = menuAvailable(kind, id) ? info.label : info.label + ' (not in this browser)'; });
      b.addEventListener('mouseleave', () => { el.querySelector('.mlabel').textContent = ''; });
    }
    el.addEventListener('click', e => {
      const b = e.target.closest && e.target.closest('[data-act]');
      if (!b) return;
      e.stopPropagation();
      menuAction(b.dataset.act);
    });
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => {
      window.addEventListener('pointerdown', outside, true);
      window.addEventListener('keydown', escKey, true);
      window.addEventListener('blur', blurClose);
    }, 0);
  }

  const outside = e => { if (menuEl && !e.composedPath().includes(host)) closeMenu(); };
  const escKey = e => { if (e.key === 'Escape' && menuEl) { e.stopPropagation(); closeMenu(); } };
  const blurClose = () => setTimeout(() => { if (menuEl && !document.hasFocus()) closeMenu(); }, 150);

  function closeMenu(instant = false) {
    if (!menuEl) return;
    const el = menuEl;
    menuEl = null;
    window.removeEventListener('pointerdown', outside, true);
    window.removeEventListener('keydown', escKey, true);
    window.removeEventListener('blur', blurClose);
    if (el.__onClose) el.__onClose();
    if (instant) { el.remove(); return; }
    el.classList.remove('show');
    setTimeout(() => el.remove(), 180);
  }

  async function menuAction(act) {
    switch (act) {
      case 'gear': closeMenu(); send({ type: 'open-options' }); return;
      case 'tab-rec':
      case 'tab-shot': {
        const t = act === 'tab-rec' ? 'rec' : 'shot';
        if (S.lastTab === t) return;
        const p = menuEl.querySelector('.mpill');
        p.classList.add('moving'); setTimeout(() => p.classList.remove('moving'), 220);
        S.lastTab = t; await api.storage.local.set({ lastTab: t }); renderMenu();
        return;
      }
      case 'tabAudio': S.tabAudio = !S.tabAudio; await api.storage.local.set({ tabAudio: S.tabAudio }); renderMenu(); return;
      case 'mic': {
        S.mic = !S.mic; await api.storage.local.set({ mic: S.mic }); renderMenu();
        if (S.mic) { const r = await send({ type: 'mic-check' }); if (r && r.granted === false) send({ type: 'ask-mic' }); }
        return;
      }
    }
    const [kind, id] = act.split(':');
    if (!menuAvailable(kind, id)) return;
    closeMenu(true);
    await frame2();
    if (kind === 'shot') screenshot(id); else record(id);
  }

  // ------------------------------------------------------------------ recording controls (rounded card)
  // The recording is paused while this card is open, so it never appears in the video.

  function fmtTime(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    const h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec % 60, p = n => String(n).padStart(2, '0');
    return h ? `${h}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
  }

  function openRecCard(rec, wasPaused) {
    if (menuEl) closeMenu(true);
    mount();
    if (toastEl) { toastEl.remove(); toastEl = null; }
    const st = { mic: !!rec.mic, tabAudio: rec.tabAudio !== false, keepPaused: !!wasPaused, done: false };
    const el = document.createElement('div');
    el.className = 'menu';
    const what = { tab: 'Recording this tab', area: 'Recording an area', screen: 'Recording screen' }[rec.mode] || 'Recording';
    setHTML(el, `
      <div class="rtop"><span class="rdot"></span><span class="rtime">${fmtTime(rec.elapsed)}</span><span class="rwhat">${what}</span></div>
      <div class="rbar">
        <button class="rbtn" data-act="tabAudio"></button>
        <button class="rbtn" data-act="mic"></button>
        <span class="rsep"></span>
        <button class="rbtn" data-act="pause"></button>
        <span class="rgrow"></span>
        <button class="rbtn" data-act="discard" title="Discard">${svg('trash', 17)}</button>
        <button class="rbtn stop" data-act="stop" title="Stop and save">${svg('stop', 17)}</button>
      </div>
      <div class="rconfirm"><span>Discard this recording?</span>
        <span><button class="rpill" data-act="keep">Keep</button> <button class="rpill primary" data-act="yes">Discard</button></span></div>
      <div class="rhint">Paused · click outside to continue</div>`);
    const $r = s => el.querySelector(s);
    const render = () => {
      const a = $r('[data-act="tabAudio"]'), m = $r('[data-act="mic"]'), p = $r('[data-act="pause"]');
      setHTML(a, svg(st.tabAudio ? 'speaker' : 'speakerOff', 17));
      a.classList.toggle('off', !st.tabAudio);
      a.title = (rec.mode === 'screen' ? 'System sound' : 'Tab sound') + (st.tabAudio ? ': on' : ': off');
      setHTML(m, svg(st.mic ? 'mic' : 'micOff', 17));
      m.classList.toggle('off', !st.mic);
      m.title = st.mic ? 'Microphone: on' : 'Microphone: off';
      setHTML(p, svg('pause', 17));
      p.classList.toggle('on', st.keepPaused);
      p.title = st.keepPaused ? 'Stays paused when you close this (click to undo)' : 'Keep it paused';
      $r('.rhint').textContent = st.keepPaused ? 'Stays paused after you close this' : 'Paused · click outside to continue';
    };
    render();
    root.appendChild(el);
    menuEl = el;
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));

    const finish = async (cmd) => {
      if (st.done) return;
      st.done = true;
      closeMenu(true);
      if (cmd) await send({ type: 'rec-command', cmd });
    };
    // closing the card any other way (outside click, Esc) carries on recording
    el.__onClose = () => { if (!st.done) { st.done = true; if (!st.keepPaused) send({ type: 'rec-command', cmd: 'resume' }); } };

    el.addEventListener('click', async e => {
      const b = e.target.closest && e.target.closest('[data-act]');
      if (!b) return;
      e.stopPropagation();
      switch (b.dataset.act) {
        case 'tabAudio': st.tabAudio = !st.tabAudio; render(); send({ type: 'rec-command', cmd: 'toggle-tabaudio' }); break;
        case 'mic': st.mic = !st.mic; render(); send({ type: 'rec-command', cmd: 'toggle-mic' }); break;
        case 'pause': st.keepPaused = !st.keepPaused; render(); break;
        case 'stop': finish('stop'); break;
        case 'discard': $r('.rconfirm').classList.add('show'); break;
        case 'keep': $r('.rconfirm').classList.remove('show'); break;
        case 'yes': finish('discard'); break;
      }
    });
    setTimeout(() => {
      window.addEventListener('pointerdown', outside, true);
      window.addEventListener('keydown', escKey, true);
    }, 0);
  }

  // ------------------------------------------------------------------ messages from the background

  api.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    switch (msg.type) {
      case 'rec-card':
        if (menuEl) { closeMenu(); break; }
        openRecCard(msg.rec || {}, !!msg.wasPaused);
        break;
      case 'menu':
        canTabCapture = msg.canTabCapture !== false;
        if (!selecting) openMenu();
        break;
      case 'run':
        (async () => {
          S = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
          await sleep(120);                        // let the menu close and the page get focus back
          if (msg.kind === 'shot') screenshot(msg.mode); else record(msg.mode);
        })();
        break;
      case 'toggle-bar':
        canTabCapture = msg.canTabCapture !== false;
        if (selecting) return;
        if (open && dock < 0.5) close();
        else if (open && dockTo > 0.5) { lastOver = performance.now() + 1500; showLogo = true; animate(0, 320); }
        else show();
        break;
      case 'page-rec-cmd':
        if (!pageRec) break;
        switch (msg.cmd) {
          case 'pause': pageRec.pause(); break;
          case 'resume': pageRec.resume(); break;
          case 'toggle-pause': pageRec.paused ? pageRec.resume() : pageRec.pause(); break;
          case 'toggle-mic': pageRec.setMic(!pageRec.mic); break;
          case 'stop': finishPageRec(false); break;
          case 'discard': finishPageRec(true); break;
        }
        break;
      case 'rec-progress':
        if (toastEl) { const sub = toastEl.querySelector('.d'); if (sub) sub.textContent = `Making an MP4… ${msg.pct}%`; }
        break;
      case 'rec-ended':
        if (frameEl) { frameEl.remove(); frameEl = null; }
        if (msg.discarded) toast('Recording discarded');
        else if (msg.saved) toast('Recording saved', `${msg.filename}  ·  ${msg.folder === '' && S.saveAs ? 'Saved where you chose' : 'Downloads' + (msg.folder ? '/' + msg.folder : '')}`, {
          icon: 'record', ms: 8000,
          onClick: msg.downloadId != null ? () => send({ type: 'show-download', id: msg.downloadId }) : null,
          onDelete: msg.downloadId != null ? () => send({ type: 'delete-download', id: msg.downloadId }) : null,
        });
        else if (msg.error) toast('Recording failed', msg.error, { icon: 'close', ms: 6000 });
        afterCapture();
        break;
    }
  });

  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const [k, v] of Object.entries(changes)) S[k] = v.newValue;
    if (open) renderButtons();
  });
})();
